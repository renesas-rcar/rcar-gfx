/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_sample.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>
#include <memory.h>
#include <argp.h>

#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  STATICS
 ****************************************************************************/
static const char vsFile[] = "./res/TriangleVS.spv";
static const char fsFile[] = "./res/TriangleFS.spv";
static VkShaderModule vs = VK_NULL_HANDLE;
static VkShaderModule fs = VK_NULL_HANDLE;
static VkImageMemoryBarrier barrierPresentToAttachment = {
	.sType                           = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
	.pNext                           = NULL,
	.srcAccessMask                   = VK_ACCESS_MEMORY_READ_BIT,
	.dstAccessMask                   = VK_ACCESS_COLOR_ATTACHMENT_WRITE_BIT,
	.oldLayout                       = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
	.newLayout                       = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
	.srcQueueFamilyIndex             = VK_QUEUE_FAMILY_IGNORED,
	.dstQueueFamilyIndex             = VK_QUEUE_FAMILY_IGNORED,
	.subresourceRange = {
		.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT,
		.baseMipLevel   = 0,
		.levelCount     = 1,
		.baseArrayLayer = 0,
		.layerCount     = 1,
	},
	.image                           = NULL};
static VkImageMemoryBarrier barrierAttachmentToPresent = {
	.sType                           = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
	.pNext                           = NULL,
	.srcAccessMask                   = VK_ACCESS_MEMORY_WRITE_BIT,
	.dstAccessMask                   = VK_ACCESS_MEMORY_READ_BIT,
	.oldLayout                       = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
	.newLayout                       = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
	.srcQueueFamilyIndex             = VK_QUEUE_FAMILY_IGNORED,
	.dstQueueFamilyIndex             = VK_QUEUE_FAMILY_IGNORED,
	.subresourceRange = {
		.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT,
		.baseMipLevel   = 0,
		.levelCount     = 1,
		.baseArrayLayer = 0,
		.layerCount     = 1,
	},
	.image                           = NULL};
static VkClearValue clearValues[2] = {
	{
		.color = { /* VkClearColorValue */
			.float32[0] = 0.4f,
			.float32[1] = 0.6f,
			.float32[2] = 0.9f,
			.float32[3] = 1.0f},
	},
	{
		.depthStencil = { /* VkClearDepthStencilValue */
			.depth   = 1.0f,
			.stencil = 0},
	}
};
static VkRenderPassBeginInfo renderPassBeginInfo = {
	.sType                    = VK_STRUCTURE_TYPE_RENDER_PASS_BEGIN_INFO,
	.pNext                    = NULL,
	.renderPass               = NULL,
	.framebuffer              = NULL,
	.renderArea.offset.x      = 0,
	.renderArea.offset.y      = 0,
	.renderArea.extent.width  = 0,
	.renderArea.extent.height = 0,
	.clearValueCount          = 2,
	.pClearValues             = &clearValues[0]};
static VkPresentInfoKHR presentInfo = {
	.sType              = VK_STRUCTURE_TYPE_PRESENT_INFO_KHR,
	.pNext              = NULL,
	.swapchainCount     = 1,
	.pSwapchains        = NULL,
	.pImageIndices      = NULL,
	.pWaitSemaphores    = NULL,
	.waitSemaphoreCount = 0,
	.pResults           = NULL};
static uint32_t maxFrame = 750;
static float rotateMag = 2.0f;
static bool showFPS = false;

/*****************************************************************************
 * Function Name  : parse_option
 * Description    : 
 *****************************************************************************/
static error_t parse_option(int key, char *arg, struct argp_state *state)
{
	switch (key)
	{
		case 'p':
			g_PlaneIndex = strtol(arg, NULL, 10);
			break;
		case 'w':
			g_PlaneExtent.width = strtol(arg, NULL, 10);
			break;
		case 'h':
			g_PlaneExtent.height = strtol(arg, NULL, 10);
			break;
		case 'd':
			g_ConnectorIndex = strtol(arg, NULL, 10);
			break;
		case 'P':
			if (strncmp(arg, "immediate", strlen("immediate")) == 0) {
				g_PresentMode = VK_PRESENT_MODE_IMMEDIATE_KHR;
			}
			else if (strncmp(arg, "mailbox", strlen("mailbox")) == 0) {
				g_PresentMode = VK_PRESENT_MODE_MAILBOX_KHR;
			}
			else if (strncmp(arg, "fifo", strlen("fifo")) == 0) {
				g_PresentMode = VK_PRESENT_MODE_FIFO_KHR;
			}
			else if (strncmp(arg, "fifo-relaxed", strlen("fifo-relaxed")) == 0) {
				g_PresentMode = VK_PRESENT_MODE_FIFO_RELAXED_KHR;
			}
			else
			{
				g_PresentMode = strtol(arg, NULL, 10);
				switch (g_PresentMode) {
				case VK_PRESENT_MODE_IMMEDIATE_KHR:
				case VK_PRESENT_MODE_MAILBOX_KHR:
				case VK_PRESENT_MODE_FIFO_KHR:
				case VK_PRESENT_MODE_FIFO_RELAXED_KHR:
					break;
				default:
					printf("Invalid argument for presentMode");
					return ARGP_ERR_UNKNOWN;
				}
			}
			break;
		case 'f':
			maxFrame = strtol(arg, NULL, 10);
			break;
		case 'F':
			showFPS = true;
			break;
		default:
			return ARGP_ERR_UNKNOWN;
	}
	return 0;
}
/*****************************************************************************
 * Function Name  : main
 * Description    : 
 *****************************************************************************/
int main(int argc, char *argv[])
{
	uint32_t i;
	const struct argp_option options[] = {
		{"plane",        'p', "PLANE",     0, "Plane index(default=-1)." },
		{"width",        'w', "WIDTH",     0, "Surface width(default=<display width>)." },
		{"height",       'h', "HEIGHT",    0, "Surface height(default=<display height>)." },
		{"display",      'd', "DISPLAY",   0, "Display Index(default=0)." },
		{"present-mode", 'P', "MODE",      0, "Preset Mode to use [immediate, mailbox, fifo, fifo-relaxed] (default=2 : fifo)." },
		{"frame",        'f', "FRAME",     0, "Frame Count(default=750)." },
		{"fps",          'F', 0,           0, "Show fps." },
		{ 0 }
	};
	struct argp sArgp = {
		options,
		parse_option,
		NULL,
		"Vulkan sample -- vulkan sample application",
	};

	argp_parse(&sArgp, argc, argv, 0, 0, NULL);

	printf("-------------------------------------------------------\n");
	printf(" Vulkan sample application\n");
	printf("-------------------------------------------------------\n");

	/* 1.1. Creating Vulkan Instance */
	CreateInstance();
	/* 1.2. Getting Physical Devices */
	EnumeratePhysicalDevices();
	GetPhysicalDeviceProperties();
	/* 1.3. Generating Device */
	/* 1.4. Getting Queue */
	CreateDeviceAndQueue();
	BindExtensionsAPI(); /* Get Extension Function pointer */
	CreateFence();
	CreateSemaphore();
	/* 1.5. Generating CommandPool */
	CreateCommandPool();
	/* 1.6. Generating CommandBuffer */
	AllocateCommandBuffers();
	/* 2.1. Generating Surface */
	CreateDisplayPlaneSurface();
	/* 2.2. Generating Swapchain */
	CreateSwapchain();
	/* 3.1. Generating Image/ImageView */
	CreateImage();
	CreateImageView();
	/* 3.2. Generating DepthStencil Buffer */
	CreateDepthStencilBuffer();
	/* 3.3. Generating RenderPass */
	CreateRenderPass();
	/* 3.4. Generating Framebuffer */
	CreateFramebuffer();
	/* 4.1. Generating Shader */
	vs = LoadShader(vsFile); /* Load Vertex shader */
	fs = LoadShader(fsFile); /* Load Fragment shader */
	/* 4.2. Generating GraphicsPipeline */
	CreateVertexBufferAndSetup();
	CreateUniformBuffer();
	CreateDescriptorPool();
	CreateDescriptorSetLayout();
	UpdateDescriptorSets();
	CreatePipelineLayout();
	CreatePipelineCache();
	CreateGraphicsPipelines(vs, fs);
	/* 5.1. Start/End recording the command */
	for (i = 0; i < g_SwapchainCount; i++) {
		VkCommandBuffer command = g_CommandBuffers[i];
		VkDeviceSize deviceSize = 0;

		/* 5.2. Start/End RenderPass */
		BeginCommandBuffer(command, g_Framebuffers[i]);
		vkCmdSetViewport(command, 0, 1, &g_Viewport);
		vkCmdSetScissor(command, 0, 1, &g_Scissor);
		barrierPresentToAttachment.image = g_BackBuffers[i].Image;
		vkCmdPipelineBarrier(command,
							 VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
							 VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
							 0, 0, NULL, 0, NULL, 1, &barrierPresentToAttachment);
		renderPassBeginInfo.renderPass               = g_RenderPass;
		renderPassBeginInfo.framebuffer              = g_Framebuffers[i];
		renderPassBeginInfo.renderArea.offset.x      = 0;
		renderPassBeginInfo.renderArea.offset.y      = 0;
		renderPassBeginInfo.renderArea.extent.width  = g_PlaneExtent.width;
		renderPassBeginInfo.renderArea.extent.height = g_PlaneExtent.height;
		vkCmdBeginRenderPass(command, &renderPassBeginInfo, VK_SUBPASS_CONTENTS_INLINE);
		vkCmdBindPipeline(command, VK_PIPELINE_BIND_POINT_GRAPHICS, g_Pipeline);
		vkCmdBindDescriptorSets(command,
								VK_PIPELINE_BIND_POINT_GRAPHICS,
								g_PipelineLayout, 0, 1, &g_DescSet, 0, NULL);
		vkCmdBindVertexBuffers(command, 0, 1, &g_VertexBuf.Buffer, &deviceSize);
		vkCmdDraw(command, 3, 1, 0, 0);
		vkCmdEndRenderPass(command);
		barrierAttachmentToPresent.image = g_BackBuffers[i].Image;
		vkCmdPipelineBarrier(command,
							 VK_PIPELINE_STAGE_COLOR_ATTACHMENT_OUTPUT_BIT,
							 VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
							 0, 0, NULL, 0, NULL, 1, &barrierAttachmentToPresent);
		EndCommandBuffer(command);
	}

	for (i = 0; i < maxFrame; i++) {
		uint32_t timeout_ns = 100 * 1000 * 1000; /* 100ms */

		/* 6.1. Getting Index of Image */
		/* 6.2. Submitting Command */
		/* 6.3. Queuing Image Presentation */
		{/* Rotate Object */
			float projection[4][4], modelview[4][4], transform[4][4];
			uint8_t *mappedData = NULL;

			vkMapMemory(g_Device, g_UniformBuf.Memory, 0,
						g_UniformBufBufferSize, 0, (void**)&mappedData);
			LoadIdentity(projection);
			Persp(projection, 60.0f, 1.0f, 0.1f, 100.0f);
			LoadIdentity(modelview);
			Translate(modelview, 0.0f, 0.0f, -2.0f);
			Rotate(modelview, 0.0f, 0.1f, 0.0f, ((float)sin((i * rotateMag) / 180.0f) * 180.0f));
			MultMatrix(transform, modelview, projection);
			if (mappedData) memcpy(mappedData, &transform, sizeof(transform));
			vkUnmapMemory(g_Device, g_UniformBuf.Memory);
		}

		fn_vkAcquireNextImageKHR(g_Device, g_Swapchain, timeout_ns,
								 g_GraphicsImageAcquireSemaphore, VK_NULL_HANDLE, &g_BufferIndex);

		calcFPS(showFPS);

		vkResetFences(g_Device, 1, &g_GraphicsFence);
		QueueSubmit(g_CommandBuffers[g_BufferIndex], g_GraphicsFence,
					g_GraphicsImageAcquireSemaphore, g_GraphicsRenderingCompleteSemaphore);

		presentInfo.waitSemaphoreCount = 1;
		presentInfo.pWaitSemaphores    = &g_GraphicsRenderingCompleteSemaphore;
		presentInfo.pSwapchains        = &g_Swapchain;
		presentInfo.pImageIndices      = &g_BufferIndex;
		fn_vkQueuePresentKHR(g_GraphicsQueue, &presentInfo);
	}

	/* Make sure that the device to be destroy is not referenced. */
	DeviceWaitIdle();

	/* 7. Destroying object */
	DestroyUniformBuffer();
	DestroyVertexBuffer();
	DestroyGraphicsPipeline();
	DestroyPipelineCache();
	DestroyPipelineLayout();
	FreeDescriptorSets();
	DestroyDescriptorSetLayout();
	DestroyDescriptorPool();
	vkDestroyShaderModule(g_Device, vs, NULL);
	vkDestroyShaderModule(g_Device, fs, NULL);
	DestroyFramebuffer();
	DestroyRenderPass();
	DestroyDepthImageAndImageView();
	DestroyImageAndImageView();
	DestroySwapchain();
	DestroySurface();
	FreeCommandBuffers();
	DestroyCommandPool();
	DestroySemaphore();
	DestroyFence();
	DestroyDevice();
	DestroyInstance();
	printf("-------------------------------------------------------\n");

	return 1;
}

