#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_COMMON_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_COMMON_H

#ifdef __cplusplus
extern "C" {
#endif



LdrReturnValue ldr_user_register_swc_injection(LdrContext *context, 
                                                uint32_t id, 
                                                void (*swc_injection_callback)(uint32_t id,
                                                                                void *data,
                                                                                uint32_t len));

#ifdef __cplusplus
}
#endif


#endif