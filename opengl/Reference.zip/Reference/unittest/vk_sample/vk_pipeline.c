/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_pipeline.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2017.10.16
//            - Modify memoryTypeIndex of MemoryAllocateInfo.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <memory.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  DEFINES
 ****************************************************************************/
struct Vertex {
	float pos[3];
	float coord[2];
	float color[4];
};
struct Vertex vertices[3] = {
	{{-0.35f, 0.35f, 0.0f}, {0.0f, 0.0f}, {1.0f, 0.0f, 0.0f, 1.0f}},
	{{ 0.00f,-0.35f, 0.0f}, {0.5f, 1.0f}, {0.0f, 1.0f, 0.0f, 1.0f}},
	{{ 0.35f, 0.35f, 0.0f}, {1.0f, 0.0f}, {0.0f, 0.0f, 1.0f, 1.0f}}
};

/* for Uniform Buffer */
static float g_Transform[4][4] = {
	{1.0f, 0.0f, 0.0f, 0.0f},
	{0.0f, 1.0f, 0.0f, 0.0f},
	{0.0f, 0.0f, 1.0f, 0.0f},
	{0.0f, 0.0f, 0.0f, 1.0f}
};

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
vk_vertex_buffer g_VertexBuf = { NULL };
vk_uniform_buffer g_UniformBuf = { NULL };
uint32_t g_UniformBufBufferSize = 0;
VkDescriptorPool g_DescPool = NULL;
VkDescriptorSetLayout g_DescSetLayout = NULL;
VkDescriptorSet g_DescSet = NULL;
VkPipelineLayout g_PipelineLayout = NULL;
VkPipelineCache g_PipelineCache = NULL;
VkPipeline g_Pipeline = NULL;
VkViewport g_Viewport = { 0 };
VkRect2D g_Scissor = { 0 };

/*****************************************************************************
 * Function Name  : CreateVertexBufferAndSetup
 * Description    : Create VertexBuffer and Setup
 *****************************************************************************/
VkResult CreateVertexBufferAndSetup(void)
{
	VkBufferCreateInfo bufferCreateInfo = {
		.sType                 = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
		.pNext                 = NULL,
		.usage                 = VK_BUFFER_USAGE_VERTEX_BUFFER_BIT,
		.size                  = sizeof(struct Vertex) * 3,
		.queueFamilyIndexCount = 0,
		.pQueueFamilyIndices   = NULL,
		.sharingMode           = VK_SHARING_MODE_EXCLUSIVE,
		.flags                 = 0};
	VkMemoryRequirements memoryRequirements;
	VkMemoryAllocateInfo memoryAllocInfo = {
		.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
		.pNext           = NULL,
		.memoryTypeIndex = 0,
		.allocationSize  = 0};
	uint8_t *mapData = NULL;
	uint32_t offset = 0;
	VkResult ret;

	ret = vkCreateBuffer(g_Device, &bufferCreateInfo, NULL, &g_VertexBuf.Buffer);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateBuffer failed.\n");
		return ret;
	}

	vkGetBufferMemoryRequirements(g_Device, g_VertexBuf.Buffer, &memoryRequirements);

	memoryAllocInfo.allocationSize = memoryRequirements.size;
	memoryAllocInfo.memoryTypeIndex = GetMemoryTypeIndex(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
														 memoryRequirements.memoryTypeBits);

	ret = vkAllocateMemory(g_Device, &memoryAllocInfo, NULL, &g_VertexBuf.Memory);
	if (ret != VK_SUCCESS) {
		printf("error: vkAllocateMemory failed.\n");
		return ret;
	}

	ret = vkMapMemory(g_Device, g_VertexBuf.Memory, 0, memoryRequirements.size, 0, (void**)&mapData);
	if (ret != VK_SUCCESS) {
		printf("error: vkMapMemory failed.\n");
		return ret;
	}
	memcpy(mapData, vertices, sizeof(vertices));
	vkUnmapMemory(g_Device, g_VertexBuf.Memory);

	ret = vkBindBufferMemory(g_Device, g_VertexBuf.Buffer, g_VertexBuf.Memory, 0);
	if (ret != VK_SUCCESS) {
		printf("error: vkBindBufferMemory failed.\n");
		return ret;
	}

	g_VertexBuf.Bindings.binding   = 0;
	g_VertexBuf.Bindings.inputRate = VK_VERTEX_INPUT_RATE_VERTEX;
	g_VertexBuf.Bindings.stride = sizeof(struct Vertex);

	g_VertexBuf.Attributes[0].binding  = 0;
	g_VertexBuf.Attributes[0].location = 0;
	g_VertexBuf.Attributes[0].format   = VK_FORMAT_R32G32B32_SFLOAT;
	g_VertexBuf.Attributes[0].offset   = offset;
	offset = offset + (sizeof(float) * 3);

	g_VertexBuf.Attributes[1].binding  = 0;
	g_VertexBuf.Attributes[1].location = 1;
	g_VertexBuf.Attributes[1].format   = VK_FORMAT_R32G32_SFLOAT;
	g_VertexBuf.Attributes[1].offset   = offset;
	offset = offset + (sizeof(float) * 2);

	g_VertexBuf.Attributes[2].binding  = 0;
	g_VertexBuf.Attributes[2].location = 2;
	g_VertexBuf.Attributes[2].format   = VK_FORMAT_R32G32B32A32_SFLOAT;
	g_VertexBuf.Attributes[2].offset   = offset;
	offset = offset + (sizeof(float) * 4);

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateUniformBuffer
 * Description    : Create Uniform Buffer
 *****************************************************************************/
VkResult CreateUniformBuffer(void)
{
	VkBufferCreateInfo bufferCreateInfo = {
		.sType                 = VK_STRUCTURE_TYPE_BUFFER_CREATE_INFO,
		.pNext                 = NULL,
		.usage                 = VK_BUFFER_USAGE_UNIFORM_BUFFER_BIT,
		.size                  = sizeof(g_Transform),
		.queueFamilyIndexCount = 0,
		.pQueueFamilyIndices   = NULL,
		.sharingMode           = VK_SHARING_MODE_EXCLUSIVE,
		.flags                 = 0};
	VkMemoryRequirements memoryRequirements;
	VkMemoryAllocateInfo memoryAllocInfo = {
		.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
		.pNext           = NULL,
		.memoryTypeIndex = 0,
		.allocationSize  = 0};
	uint8_t *mappedData = NULL;
	VkResult ret;

	ret = vkCreateBuffer(g_Device, &bufferCreateInfo, NULL, &g_UniformBuf.Buffer);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateBuffer failed.\n");
		return ret;
	}

	vkGetBufferMemoryRequirements(g_Device, g_UniformBuf.Buffer, &memoryRequirements);
	g_UniformBufBufferSize = memoryRequirements.size;

	memoryAllocInfo.memoryTypeIndex = GetMemoryTypeIndex(VK_MEMORY_PROPERTY_HOST_VISIBLE_BIT,
														 memoryRequirements.memoryTypeBits);
	memoryAllocInfo.allocationSize = g_UniformBufBufferSize;
	ret = vkAllocateMemory(g_Device, &memoryAllocInfo, NULL, &g_UniformBuf.Memory);
	if (ret != VK_SUCCESS) {
		printf("error: vkAllocateMemory failed.\n");
		return ret;
	}

	ret = vkMapMemory(g_Device, g_UniformBuf.Memory, 0, g_UniformBufBufferSize, 0, (void**)&mappedData);
	if (ret != VK_SUCCESS) {
		printf("error: vkMapMemory failed.\n");
		return ret;
	}
	memcpy(mappedData, &g_Transform, sizeof(g_Transform));
	vkUnmapMemory(g_Device, g_UniformBuf.Memory);

	ret = vkBindBufferMemory(g_Device, g_UniformBuf.Buffer, g_UniformBuf.Memory, 0);
	if (ret != VK_SUCCESS) {
		printf("error: vkBindBufferMemory failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateDescriptorPool
 * Description    : Create Descriptor Pool
 *****************************************************************************/
VkResult CreateDescriptorPool(void)
{
	VkDescriptorPoolSize descriptorPoolSize = {
		.type            = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
		.descriptorCount = 1};
	VkDescriptorPoolCreateInfo descriptorPoolInfo = {
		.sType         = VK_STRUCTURE_TYPE_DESCRIPTOR_POOL_CREATE_INFO,
		.pNext         = NULL,
		.flags         = 0,
		.maxSets       = 1,
		.poolSizeCount = 1,
		.pPoolSizes    = &descriptorPoolSize};
	VkResult ret;

	ret = vkCreateDescriptorPool(g_Device, &descriptorPoolInfo, NULL, &g_DescPool);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateDescriptorPool failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateDescriptorSetLayout
 * Description    : Create DescriptorSet Layout
 *****************************************************************************/
VkResult CreateDescriptorSetLayout(void)
{
	VkDescriptorSetLayoutBinding descriptorSetLayoutBinding = {
		.binding            = 0,
		.descriptorType     = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
		.descriptorCount    = 1,
		.stageFlags         = VK_SHADER_STAGE_VERTEX_BIT,
		.pImmutableSamplers = NULL};
	VkDescriptorSetLayoutCreateInfo descriptorSetLayoutInfo = {
		.sType        = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_LAYOUT_CREATE_INFO,
		.pNext        = NULL,
		.flags        = 0,
		.bindingCount = 1,
		.pBindings    = &descriptorSetLayoutBinding};
	VkResult ret;

	ret = vkCreateDescriptorSetLayout(g_Device, &descriptorSetLayoutInfo,
									  NULL, &g_DescSetLayout);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateDescriptorSetLayout failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : UpdateDescriptorSets
 * Description    : Update Descriptor Sets
 *****************************************************************************/
VkResult UpdateDescriptorSets(void)
{
	VkDescriptorSetAllocateInfo descriptorSetAllocInfo = {
		.sType              = VK_STRUCTURE_TYPE_DESCRIPTOR_SET_ALLOCATE_INFO,
		.pNext              = NULL,
		.descriptorPool     = g_DescPool,
		.descriptorSetCount = 1,
		.pSetLayouts        = &g_DescSetLayout};
	VkDescriptorBufferInfo descriptorBufferInfo = {
		.buffer = g_UniformBuf.Buffer,
		.offset = 0,
		.range  = sizeof(g_Transform)};
	VkWriteDescriptorSet writeDescriptorSet = {
		.sType            = VK_STRUCTURE_TYPE_WRITE_DESCRIPTOR_SET,
		.pNext            = NULL,
		.dstSet           = NULL,
		.dstBinding       = 0,
		.dstArrayElement  = 0,
		.descriptorCount  = 1,
		.descriptorType   = VK_DESCRIPTOR_TYPE_UNIFORM_BUFFER,
		.pImageInfo       = NULL,
		.pBufferInfo      = &descriptorBufferInfo,
		.pTexelBufferView = NULL};
	VkResult ret;

	ret = vkAllocateDescriptorSets(g_Device, &descriptorSetAllocInfo, &g_DescSet);
	if (ret != VK_SUCCESS) {
		printf("error: vkAllocateDescriptorSets failed.\n");
		return ret;
	}

	writeDescriptorSet.dstSet = g_DescSet;
	vkUpdateDescriptorSets(g_Device, 1, &writeDescriptorSet, 0, NULL);

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreatePipelineLayout
 * Description    : Create Pipeline Layout
 *****************************************************************************/
VkResult CreatePipelineLayout(void)
{
	VkPipelineLayoutCreateInfo pipelineLayoutInfo = {
		.sType                  = VK_STRUCTURE_TYPE_PIPELINE_LAYOUT_CREATE_INFO,
		.pNext                  = NULL,
		.pushConstantRangeCount = 0,
		.pPushConstantRanges    = NULL,
		.setLayoutCount         = 1,
		.pSetLayouts            = &g_DescSetLayout};
	VkResult ret;

	ret = vkCreatePipelineLayout(g_Device, &pipelineLayoutInfo, NULL, &g_PipelineLayout);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreatePipelineLayout failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreatePipelineCache
 * Description    : Create Pipeline Cache
 *****************************************************************************/
VkResult CreatePipelineCache(void)
{
	VkPipelineCacheCreateInfo pipelineCacheInfo = {
		.sType           = VK_STRUCTURE_TYPE_PIPELINE_CACHE_CREATE_INFO,
		.pNext           = NULL,
		.flags           = 0,
		.initialDataSize = 0,
		.pInitialData    = NULL};
	VkResult ret;

	ret = vkCreatePipelineCache(g_Device, &pipelineCacheInfo, NULL, &g_PipelineCache);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreatePipelineCache failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateGraphicsPipelines
 * Description    : Create Graphics Pipelines
 *****************************************************************************/
VkResult CreateGraphicsPipelines(VkShaderModule vs, VkShaderModule fs)
{
	VkPipelineShaderStageCreateInfo stageInfo[2] = {/* [0]:vertex [1]:fragment */
		{
			.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
			.pNext = NULL,
			.flags = 0,
			.stage = VK_SHADER_STAGE_VERTEX_BIT,
			.module = vs,
			.pName = "main",
			.pSpecializationInfo = NULL
		},
		{
			.sType = VK_STRUCTURE_TYPE_PIPELINE_SHADER_STAGE_CREATE_INFO,
			.pNext = NULL,
			.flags = 0,
			.stage = VK_SHADER_STAGE_FRAGMENT_BIT,
			.module = fs,
			.pName = "main",
			.pSpecializationInfo = NULL
		}
	};
	VkPipelineVertexInputStateCreateInfo vertexInputInfo = {
		.sType                           = VK_STRUCTURE_TYPE_PIPELINE_VERTEX_INPUT_STATE_CREATE_INFO,
		.pNext                           = NULL,
		.flags                           = 0,
		.vertexBindingDescriptionCount   = 1,
		.pVertexBindingDescriptions      = &g_VertexBuf.Bindings,
		.vertexAttributeDescriptionCount = 3,
		.pVertexAttributeDescriptions    = g_VertexBuf.Attributes};
	VkPipelineInputAssemblyStateCreateInfo inputAssemblyInfo = {
		.sType                  = VK_STRUCTURE_TYPE_PIPELINE_INPUT_ASSEMBLY_STATE_CREATE_INFO,
		.pNext                  = NULL,
		.flags                  = 0,
		.topology               = VK_PRIMITIVE_TOPOLOGY_TRIANGLE_LIST,
		.primitiveRestartEnable = VK_FALSE};
	VkPipelineViewportStateCreateInfo viewportInfo = {
		.sType         = VK_STRUCTURE_TYPE_PIPELINE_VIEWPORT_STATE_CREATE_INFO,
		.pNext         = NULL,
		.flags         = 0,
		.viewportCount = 1,
		.pViewports    = &g_Viewport,
		.scissorCount  = 1,
		.pScissors     = &g_Scissor};
	VkPipelineRasterizationStateCreateInfo rasterizationInfo = {
		.sType                   = VK_STRUCTURE_TYPE_PIPELINE_RASTERIZATION_STATE_CREATE_INFO,
		.pNext                   = NULL,
		.flags                   = 0,
		.depthClampEnable        = VK_FALSE,
		.rasterizerDiscardEnable = VK_FALSE,
		.polygonMode             = VK_POLYGON_MODE_FILL,
		.cullMode                = VK_CULL_MODE_NONE,
		.frontFace               = VK_FRONT_FACE_COUNTER_CLOCKWISE,
		.depthBiasEnable         = VK_FALSE,
		.depthBiasConstantFactor = 0.0f,
		.depthBiasClamp          = 0.0f,
		.depthBiasSlopeFactor    = 0.0f,
		.lineWidth               = 1.0f};
	VkPipelineMultisampleStateCreateInfo multisampleInfo = {
		.sType                 = VK_STRUCTURE_TYPE_PIPELINE_MULTISAMPLE_STATE_CREATE_INFO,
		.pNext                 = NULL,
		.flags                 = 0,
		.rasterizationSamples  = VK_SAMPLE_COUNT_1_BIT,
		.sampleShadingEnable   = VK_FALSE,
		.minSampleShading      = 0.0f,
		.pSampleMask           = NULL,
		.alphaToCoverageEnable = VK_FALSE,
		.alphaToOneEnable      = VK_FALSE};
	VkStencilOpState stencilOp = {
		.failOp      = VK_STENCIL_OP_KEEP,
		.passOp      = VK_STENCIL_OP_KEEP,
		.depthFailOp = VK_STENCIL_OP_KEEP,
		.compareOp   = VK_COMPARE_OP_NEVER,
		.compareMask = 0,
		.writeMask   = 0,
		.reference   = 0};
	VkPipelineDepthStencilStateCreateInfo depthInfo = {
		.sType                 = VK_STRUCTURE_TYPE_PIPELINE_DEPTH_STENCIL_STATE_CREATE_INFO,
		.pNext                 = NULL,
		.flags                 = 0,
		.depthTestEnable       = VK_TRUE,
		.depthWriteEnable      = VK_TRUE,
		.depthCompareOp        = VK_COMPARE_OP_LESS_OR_EQUAL,
		.depthBoundsTestEnable = VK_FALSE,
		.stencilTestEnable     = VK_FALSE,
		.front                 = stencilOp,
		.back                  = stencilOp,
		.minDepthBounds        = 0.0f,
		.maxDepthBounds        = 0.0f};
	VkPipelineColorBlendAttachmentState blendState = {
		.blendEnable         = VK_FALSE,
		.srcColorBlendFactor = VK_BLEND_FACTOR_ZERO,
		.dstColorBlendFactor = VK_BLEND_FACTOR_ZERO,
		.colorBlendOp        = VK_BLEND_OP_ADD,
		.srcAlphaBlendFactor = VK_BLEND_FACTOR_ZERO,
		.dstAlphaBlendFactor = VK_BLEND_FACTOR_ZERO,
		.alphaBlendOp        = VK_BLEND_OP_ADD,
		.colorWriteMask      = 0xf};
	VkPipelineColorBlendStateCreateInfo blendInfo = {
		.sType             = VK_STRUCTURE_TYPE_PIPELINE_COLOR_BLEND_STATE_CREATE_INFO,
		.pNext             = NULL,
		.flags             = 0,
		.logicOpEnable     = VK_FALSE,
		.logicOp           = VK_LOGIC_OP_CLEAR,
		.attachmentCount   = 1,
		.pAttachments      = &blendState,
		.blendConstants[0] = 0.0f,
		.blendConstants[1] = 0.0f,
		.blendConstants[2] = 0.0f,
		.blendConstants[3] = 0.0f};
	VkDynamicState dynamicState[2] = {
		VK_DYNAMIC_STATE_VIEWPORT,
		VK_DYNAMIC_STATE_SCISSOR
	};
	VkPipelineDynamicStateCreateInfo dynamicInfo = {
		.sType             = VK_STRUCTURE_TYPE_PIPELINE_DYNAMIC_STATE_CREATE_INFO,
		.pNext             = NULL,
		.flags             = 0,
		.dynamicStateCount = 2,
		.pDynamicStates    = &dynamicState[0]};
	VkGraphicsPipelineCreateInfo graphicPipelineInfo = {
		.sType               = VK_STRUCTURE_TYPE_GRAPHICS_PIPELINE_CREATE_INFO,
		.pNext               = NULL,
		.stageCount          = 2,
		.pStages             = &stageInfo[0],
		.pVertexInputState   = &vertexInputInfo,
		.pInputAssemblyState = &inputAssemblyInfo,
		.pTessellationState  = NULL,
		.pViewportState      = &viewportInfo,
		.pRasterizationState = &rasterizationInfo,
		.pMultisampleState   = &multisampleInfo,
		.pDepthStencilState  = &depthInfo,
		.pColorBlendState    = &blendInfo,
		.pDynamicState       = &dynamicInfo,
		.layout              = g_PipelineLayout,
		.renderPass          = g_RenderPass,
		.subpass             = 0,
		.basePipelineHandle  = VK_NULL_HANDLE,
		.basePipelineIndex   = 0};
	VkResult ret;

	{
		g_Viewport.minDepth = 0.0f;
		g_Viewport.maxDepth = 1.0f;
		g_Viewport.x        = 0;
		g_Viewport.y        = 0;
		g_Viewport.width    = g_PlaneExtent.width;
		g_Viewport.height   = g_PlaneExtent.height;

		g_Scissor.offset.x      = 0;
		g_Scissor.offset.y      = 0;
		g_Scissor.extent.width  = g_PlaneExtent.width;
		g_Scissor.extent.height = g_PlaneExtent.height;
	}
	ret = vkCreateGraphicsPipelines(g_Device, g_PipelineCache, 1,
									&graphicPipelineInfo, NULL, &g_Pipeline);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateGraphicsPipelines failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroyGraphicsPipeline
 * Description    : Destroy Graphics Pipeline
 *****************************************************************************/
void DestroyGraphicsPipeline(void)
{
	if (g_Pipeline == NULL) return;

	vkDestroyPipeline(g_Device, g_Pipeline, NULL);
	g_Pipeline = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyPipelineCache
 * Description    : Destroy Pipeline Cache
 *****************************************************************************/
void DestroyPipelineCache(void)
{
	if (g_PipelineCache == NULL) return;

	vkDestroyPipelineCache(g_Device, g_PipelineCache, NULL);
	g_PipelineCache = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyPipelineLayout
 * Description    : Destroy Pipeline Layout
 *****************************************************************************/
void DestroyPipelineLayout(void)
{
	if (g_PipelineLayout == NULL) return;

	vkDestroyPipelineLayout(g_Device, g_PipelineLayout, NULL);
	g_PipelineLayout = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : FreeDescriptorSets
 * Description    : Free Descriptor Sets
 *****************************************************************************/
void FreeDescriptorSets(void)
{
	if (g_DescSet == NULL) return;

	vkFreeDescriptorSets(g_Device, g_DescPool, 1, &g_DescSet);
	g_DescSet = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyDescriptorSetLayout
 * Description    : Destroy Descriptor Set Layout
 *****************************************************************************/
void DestroyDescriptorSetLayout(void)
{
	if (g_DescSetLayout == NULL) return;

	vkDestroyDescriptorSetLayout(g_Device, g_DescSetLayout, NULL);
	g_DescSetLayout = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyDescriptorPool
 * Description    : Destroy Descriptor Pool
 *****************************************************************************/
void DestroyDescriptorPool(void)
{
	if (g_DescPool == NULL) return;

	vkDestroyDescriptorPool(g_Device, g_DescPool, NULL);
	g_DescPool = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyUniformBuffer
 * Description    : Destroy Uniform Buffer
 *****************************************************************************/
void DestroyUniformBuffer(void)
{
	if (g_UniformBuf.Memory != NULL)
		vkFreeMemory(g_Device, g_UniformBuf.Memory, NULL);

	if (g_UniformBuf.Buffer != NULL)
		vkDestroyBuffer(g_Device, g_UniformBuf.Buffer, NULL);

	g_UniformBuf.Memory = NULL;
	g_UniformBuf.Buffer = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyVertexBuffer
 * Description    : DestroyVertexBuffer
 *****************************************************************************/
void DestroyVertexBuffer(void)
{
	if (g_VertexBuf.Buffer != NULL)
		vkDestroyBuffer(g_Device, g_VertexBuf.Buffer, NULL);

	if (g_VertexBuf.Memory != NULL)
		vkFreeMemory(g_Device, g_VertexBuf.Memory, NULL);

	g_VertexBuf.Buffer = NULL;
	g_VertexBuf.Memory = NULL;

	return;
}
