/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_buffer.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2017.10.16
//            - Modify memoryTypeIndex of MemoryAllocateInfo.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
uint32_t g_SwapchainCount = 0;
vk_buffer *g_BackBuffers = NULL;
vk_depth_stencil_buffer g_Depth = { 0 };
VkFramebuffer *g_Framebuffers = NULL;

/*****************************************************************************
 * Function Name  : CreateImage
 * Description    : Create Image for BackBuffers
 *****************************************************************************/
VkResult CreateImage(void)
{
	VkImage *image;
	uint32_t count, i;
	VkResult ret;

	count = 0;
	ret = fn_vkGetSwapchainImagesKHR(g_Device, g_Swapchain, &count, NULL);
	if ((ret != VK_SUCCESS) || (count < 1)) {
		printf("error: vkGetSwapchainImagesKHR failed.\n");
		return ret;
	}

	printf("Swapchain image Count     : %d\n", count);

	image = (VkImage *)malloc(count * sizeof(VkImage));
	assert(image != (VkImage *)NULL);

	ret = fn_vkGetSwapchainImagesKHR(g_Device, g_Swapchain, &count, image);
	if (ret != VK_SUCCESS) {
		printf("error: vkGetSwapchainImagesKHR failed.\n");
		free(image);
		return ret;
	}

	g_SwapchainCount = count;
	g_BackBuffers = (vk_buffer *)malloc(count * sizeof(vk_buffer));
	assert(g_BackBuffers != (vk_buffer *)NULL);

	for (i = 0; i < count; i++) {
		g_BackBuffers[i].Image = image[i];
	}

	free(image);

	BeginCommandBuffer(g_CommandBuffers[0], (VkFramebuffer)VK_NULL_HANDLE);
	{
		VkImageMemoryBarrier barrier = {
			.sType                           = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
			.pNext                           = NULL,
			.srcAccessMask                   = 0,
			.dstAccessMask                   = 0,
			.oldLayout                       = VK_IMAGE_LAYOUT_UNDEFINED,
			.newLayout                       = VK_IMAGE_LAYOUT_PRESENT_SRC_KHR,
			.srcQueueFamilyIndex             = 0,
			.dstQueueFamilyIndex             = 0,
			.image                           = NULL,
			.subresourceRange.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT,
			.subresourceRange.baseMipLevel   = 0,
			.subresourceRange.levelCount     = 1,
			.subresourceRange.baseArrayLayer = 0,
			.subresourceRange.layerCount     = 1};

		for (i = 0; i < g_SwapchainCount; i++) {
			barrier.image = g_BackBuffers[i].Image;
			vkCmdPipelineBarrier(g_CommandBuffers[0],
								 VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT,
								 VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
								 0, 0, NULL, 0, NULL, 1, &barrier);
		}
	}
	EndCommandBuffer(g_CommandBuffers[0]);
	QueueSubmit(g_CommandBuffers[0], VK_NULL_HANDLE, VK_NULL_HANDLE, VK_NULL_HANDLE);
	QueueWaitIdle();

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateImageView
 * Description    : Create Image View
 *****************************************************************************/
VkResult CreateImageView(void)
{
	uint32_t i;
	VkImageViewCreateInfo viewInfo = {
		.sType                           = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
		.pNext                           = NULL,
		.flags                           = 0,
		.image                           = NULL,
		.viewType                        = VK_IMAGE_VIEW_TYPE_2D,
		.format                          = IMAGE_FORMAT,
		.components.r                    = VK_COMPONENT_SWIZZLE_R,
		.components.g                    = VK_COMPONENT_SWIZZLE_G,
		.components.b                    = VK_COMPONENT_SWIZZLE_B,
		.components.a                    = VK_COMPONENT_SWIZZLE_A,
		.subresourceRange.aspectMask     = VK_IMAGE_ASPECT_COLOR_BIT,
		.subresourceRange.baseMipLevel   = 0,
		.subresourceRange.levelCount     = 1,
		.subresourceRange.baseArrayLayer = 0,
		.subresourceRange.layerCount     = 1};
	VkResult ret;

	for (i = 0; i < g_SwapchainCount; i++) {
		viewInfo.image = g_BackBuffers[i].Image;
		ret = vkCreateImageView(g_Device, &viewInfo, NULL, &g_BackBuffers[i].View);
		if (ret != VK_SUCCESS) {
			printf("error: vkCreateImageView failed.\n");
			return ret;
		}
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateDepthStencilBuffer
 * Description    : Create Depth & Stencil Buffer
 *****************************************************************************/
VkResult CreateDepthStencilBuffer(void)
{
	VkImageCreateInfo imageInfo = {
		.sType                 = VK_STRUCTURE_TYPE_IMAGE_CREATE_INFO,
		.pNext                 = NULL,
		.flags                 = 0,
		.imageType             = VK_IMAGE_TYPE_2D,
		.format                = DEPTH_FORMAT,
		.extent.width          = g_PlaneExtent.width,
		.extent.height         = g_PlaneExtent.height,
		.extent.depth          = 1,
		.mipLevels             = 1,
		.arrayLayers           = 1,
		.samples               = VK_SAMPLE_COUNT_1_BIT,
		.tiling                = VK_IMAGE_TILING_LINEAR,
		.usage                 = VK_IMAGE_USAGE_DEPTH_STENCIL_ATTACHMENT_BIT,
		.sharingMode           = VK_SHARING_MODE_EXCLUSIVE,
		.queueFamilyIndexCount = 0,
		.pQueueFamilyIndices   = NULL,
		.initialLayout         = VK_IMAGE_LAYOUT_UNDEFINED};
	VkImageViewCreateInfo viewInfo = {
		.sType                           = VK_STRUCTURE_TYPE_IMAGE_VIEW_CREATE_INFO,
		.pNext                           = NULL,
		.flags                           = 0,
		.image                           = NULL,
		.viewType                        = VK_IMAGE_VIEW_TYPE_2D,
		.format                          = DEPTH_FORMAT,
		.components.r                    = VK_COMPONENT_SWIZZLE_R,
		.components.g                    = VK_COMPONENT_SWIZZLE_G,
		.components.b                    = VK_COMPONENT_SWIZZLE_B,
		.components.a                    = VK_COMPONENT_SWIZZLE_A,
		.subresourceRange.aspectMask     = VK_IMAGE_ASPECT_DEPTH_BIT,
		.subresourceRange.baseMipLevel   = 0,
		.subresourceRange.levelCount     = 1,
		.subresourceRange.baseArrayLayer = 0,
		.subresourceRange.layerCount     = 1};
	VkFormatProperties formatProps;
	VkMemoryRequirements memoryRequirements;
	VkMemoryAllocateInfo memoryAllocInfo = {
		.sType           = VK_STRUCTURE_TYPE_MEMORY_ALLOCATE_INFO,
		.pNext           = NULL,
		.allocationSize  = 0,
		.memoryTypeIndex = 0};
	VkResult ret;

	vkGetPhysicalDeviceFormatProperties(g_PhysDevice, DEPTH_FORMAT, &formatProps);

	if (formatProps.linearTilingFeatures
		& VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) {
		imageInfo.tiling = VK_IMAGE_TILING_LINEAR;
	}
	else if (formatProps.optimalTilingFeatures
			 & VK_FORMAT_FEATURE_DEPTH_STENCIL_ATTACHMENT_BIT) {
		imageInfo.tiling = VK_IMAGE_TILING_OPTIMAL;
	} else {/* use LINEAR */
		imageInfo.tiling = VK_IMAGE_TILING_LINEAR;
	}

	ret = vkCreateImage(g_Device, &imageInfo, NULL, &g_Depth.Image);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateImage failed.\n");
		return ret;
	}

	vkGetImageMemoryRequirements(g_Device, g_Depth.Image, &memoryRequirements);

	memoryAllocInfo.allocationSize = memoryRequirements.size;
	memoryAllocInfo.memoryTypeIndex = GetMemoryTypeIndex(VK_MEMORY_PROPERTY_DEVICE_LOCAL_BIT,
														 memoryRequirements.memoryTypeBits);
	ret = vkAllocateMemory(g_Device, &memoryAllocInfo, NULL, &g_Depth.Memory);
	if (ret != VK_SUCCESS) {
		printf("error: vkAllocateMemory failed.\n");
		return ret;
	}

	ret = vkBindImageMemory(g_Device, g_Depth.Image, g_Depth.Memory, 0);
	if (ret != VK_SUCCESS) {
		printf("error: vkBindImageMemory failed.\n");
		return ret;
	}

	viewInfo.image = g_Depth.Image;
	ret = vkCreateImageView(g_Device, &viewInfo, NULL, &g_Depth.View);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateImageView failed.\n");
		return ret;
	}

	BeginCommandBuffer(g_CommandBuffers[0], (VkFramebuffer)VK_NULL_HANDLE);
	{
		VkImageMemoryBarrier barrier = {
			.sType                           = VK_STRUCTURE_TYPE_IMAGE_MEMORY_BARRIER,
			.pNext                           = NULL,
			.srcAccessMask                   = 0,
			.dstAccessMask                   = VK_ACCESS_DEPTH_STENCIL_ATTACHMENT_WRITE_BIT,
			.oldLayout                       = VK_IMAGE_LAYOUT_UNDEFINED,
			.newLayout                       = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
			.srcQueueFamilyIndex             = 0,
			.dstQueueFamilyIndex             = 0,
			.image                           = g_Depth.Image,
			.subresourceRange.aspectMask     = VK_IMAGE_ASPECT_DEPTH_BIT,
			.subresourceRange.baseMipLevel   = 0,
			.subresourceRange.levelCount     = 1,
			.subresourceRange.baseArrayLayer = 0,
			.subresourceRange.layerCount     = 1};

		vkCmdPipelineBarrier(g_CommandBuffers[0],
							 VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
							 VK_PIPELINE_STAGE_TOP_OF_PIPE_BIT,
							 0, 0, NULL, 0, NULL, 1, &barrier);
	}
	EndCommandBuffer(g_CommandBuffers[0]);
	QueueSubmit(g_CommandBuffers[0], VK_NULL_HANDLE, VK_NULL_HANDLE, VK_NULL_HANDLE);
	QueueWaitIdle();

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateFramebuffer
 * Description    : Create Framebuffer
 *****************************************************************************/
VkResult CreateFramebuffer(void)
{
	uint32_t i;
	VkImageView imageViewAttachments[2];
	VkFramebufferCreateInfo fbCreateInfo = {
		.sType           = VK_STRUCTURE_TYPE_FRAMEBUFFER_CREATE_INFO,
		.pNext           = NULL,
		.flags           = 0,
		.renderPass      = g_RenderPass,
		.attachmentCount = 2,
		.pAttachments    = &imageViewAttachments[0],
		.width           = g_PlaneExtent.width,
		.height          = g_PlaneExtent.height,
		.layers          = 1};
	VkResult ret;

	g_Framebuffers = (VkFramebuffer *)malloc(g_SwapchainCount * sizeof(VkFramebuffer));
	assert(g_Framebuffers != (VkFramebuffer *)NULL);

	for (i = 0; i < g_SwapchainCount; i++) {
		imageViewAttachments[0] = g_BackBuffers[i].View;
		imageViewAttachments[1] = g_Depth.View;
		ret = vkCreateFramebuffer(g_Device, &fbCreateInfo, NULL, &g_Framebuffers[i]);
		if (ret != VK_SUCCESS) {
			printf("error: vkCreateFramebuffer failed.\n");
			return ret;
		}
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroyImageAndImageView
 * Description    : Destroy Image and ImageView
 *****************************************************************************/
void DestroyImageAndImageView(void)
{
	uint32_t i;

	if (g_BackBuffers == NULL) return;

	for (i = 0; i < g_SwapchainCount; i++) {
		if (g_BackBuffers[i].View != NULL)
			vkDestroyImageView(g_Device, g_BackBuffers[i].View, NULL);
		// g_BackBuffers[i].Image -> swapchain image
	}

	free(g_BackBuffers);
	g_BackBuffers = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyDepthImageAndImageView
 * Description    : Destroy Depth Image and ImageView
 *****************************************************************************/
void DestroyDepthImageAndImageView(void)
{
	if (g_Depth.View != NULL)
		vkDestroyImageView(g_Device, g_Depth.View, NULL);
	if (g_Depth.Image != NULL)
		vkDestroyImage(g_Device, g_Depth.Image, NULL);
	if (g_Depth.Memory != NULL)
		vkFreeMemory(g_Device, g_Depth.Memory, NULL);

	g_Depth.View   = NULL;
	g_Depth.Image  = NULL;
	g_Depth.Memory = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyFramebuffer
 * Description    : Destroy Framebuffer
 *****************************************************************************/
void DestroyFramebuffer(void)
{
	uint32_t i;

	if (g_Framebuffers == NULL) return;

	for (i = 0; i < g_SwapchainCount; i++) {
		vkDestroyFramebuffer(g_Device, g_Framebuffers[i], NULL);
	}

	free(g_Framebuffers);
	g_Framebuffers = NULL;

	return;
}
