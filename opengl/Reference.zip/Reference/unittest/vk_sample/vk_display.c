/****************************************************************************/
// (C) 2016-2018 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_display.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2017.1.5
//            - Add the debug log for vkGetPhysicalDeviceDisplayPropertiesKHR.
//            - Add the debug log for vkGetDisplayModePropertiesKHR.
//          : 2017.10.31
//            - Add a check on the supported surface.
//            - Change in the default plane.
//          : 2018.4.23
//            - Fix check of currentDisplay.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
uint32_t g_ConnectorIndex = 0;
int32_t g_PlaneIndex = -1;
VkExtent2D g_PlaneExtent = {0, 0};
VkPresentModeKHR g_PresentMode = VK_PRESENT_MODE_FIFO_KHR;

VkDisplayKHR g_Display = NULL;
VkSurfaceKHR g_Surface = NULL;
VkSwapchainKHR g_Swapchain = NULL;

/*****************************************************************************
 * Function Name  : CreateDisplayPlaneSurface
 * Description    : Create Display Plane Surface
 *****************************************************************************/
VkResult CreateDisplayPlaneSurface(void)
{
	VkDisplayPropertiesKHR *dispProps;
	VkDisplayModePropertiesKHR *modeProps;
	VkDisplaySurfaceCreateInfoKHR surfaceCreateInfo = {
		.sType           = VK_STRUCTURE_TYPE_DISPLAY_SURFACE_CREATE_INFO_KHR,
		.pNext           = NULL,
		.flags           = 0,
		.displayMode     = NULL,
		.planeIndex      = 3,
		.planeStackIndex = 0,
		.transform       = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR,
		.globalAlpha     = 0.0f,
		.alphaMode       = VK_DISPLAY_PLANE_ALPHA_PER_PIXEL_BIT_KHR,
		.imageExtent     = { 0 }};
	uint32_t count, i;
	VkResult ret;

	uint32_t displayModeIndex = 0;
	uint32_t planeIndex = 0;

	count = 0;
	ret = fn_vkGetPhysicalDeviceDisplayPropertiesKHR(g_PhysDevice, &count, NULL);
	if ((ret != VK_SUCCESS) || (count < 1)) {
		printf("error: vkGetPhysicalDeviceDisplayPropertiesKHR failed.\n");
		return ret;
	}

	printf("Physical Display Count    : %d\n", count);

	dispProps = (VkDisplayPropertiesKHR *)malloc(count * sizeof(VkDisplayPropertiesKHR));
	assert(dispProps != (VkDisplayPropertiesKHR *)NULL);

	ret = fn_vkGetPhysicalDeviceDisplayPropertiesKHR(g_PhysDevice, &count, dispProps);
	if ((ret != VK_SUCCESS) && (ret != VK_INCOMPLETE)) {
		printf("error: vkGetPhysicalDeviceDisplayPropertiesKHR failed.\n");
		free(dispProps);
		return ret;
	}
	else if (ret == VK_INCOMPLETE) {
		printf("warning: vkGetPhysicalDeviceDisplayPropertiesKHR returned the incomplete value.\n");
	}

	for (i = 0; i < count; i++) {
		printf("                       %2d : %s%s\n",
			   i,
			   dispProps[i].displayName,
			   (i == g_ConnectorIndex) ? " (Use Display)" : "");
	}
	g_Display = dispProps[g_ConnectorIndex].display;

	// choose the display mode index
	{
		// get display modes
		count = 0;
		ret = fn_vkGetDisplayModePropertiesKHR(g_PhysDevice, g_Display, &count, NULL);
		if ((ret != VK_SUCCESS) || (count < 1)) {
			printf("error: vkGetDisplayModePropertiesKHR failed.\n");
			free(dispProps);
			return ret;
		}

		printf("Display Mode Count        : %d\n", count);

		modeProps = (VkDisplayModePropertiesKHR *)malloc(count * sizeof(VkDisplayModePropertiesKHR));
		assert(modeProps != (VkDisplayModePropertiesKHR *)NULL);

		ret = fn_vkGetDisplayModePropertiesKHR(g_PhysDevice, g_Display, &count, modeProps);
		if ((ret != VK_SUCCESS) && (ret != VK_INCOMPLETE)) {
			printf("error: vkGetDisplayModePropertiesKHR failed.\n");
			free(modeProps);
			free(dispProps);
			return ret;
		}
		else if (ret == VK_INCOMPLETE) {
			printf("warning: vkGetDisplayModePropertiesKHR returned the incomplete value.\n");
		}

		// choose the display mode index
		bool find = false;

		if (g_PlaneIndex == -1) {
			if (g_PlaneExtent.width == 0 && g_PlaneExtent.height == 0) {
				displayModeIndex = 0;
				find = true;
			}

			for (i = 0; i < count && find == false; i++) {
				if (g_PlaneExtent.width == modeProps[i].parameters.visibleRegion.width &&
				    g_PlaneExtent.height == modeProps[i].parameters.visibleRegion.height) {
					displayModeIndex = i;
					find = true;
				}
			}

			if (!find) {
				printf("unmatch display mode.\n");
				free(modeProps);
				free(dispProps);
				return VK_NOT_READY;
			}
		}

		printf("Chosen Display Mode       : [%u] %ux%u @%uHz\n", displayModeIndex,
			modeProps[displayModeIndex].parameters.visibleRegion.width,
			modeProps[displayModeIndex].parameters.visibleRegion.height,
			modeProps[displayModeIndex].parameters.refreshRate);
	}

	// choose the plane index
	{
		VkDisplayPlanePropertiesKHR *planeProps;
		VkDisplayKHR *supportedDisplays;
		bool find = false;
		int32_t localIndex = 0;

		// get property of planes
		uint32_t planeCount = 0;
		ret = fn_vkGetPhysicalDeviceDisplayPlanePropertiesKHR(g_PhysDevice, &planeCount, NULL);
		if (ret != VK_SUCCESS) {
			printf("error: vkGetPhysicalDeviceDisplayPlanePropertiesKHR failed.\n");
			free(modeProps);
			free(dispProps);
			return ret;
		}

		planeProps = (VkDisplayPlanePropertiesKHR *)malloc(planeCount * sizeof(VkDisplayPlanePropertiesKHR));
		assert(planeProps != (VkDisplayPlanePropertiesKHR *)NULL);

		ret = fn_vkGetPhysicalDeviceDisplayPlanePropertiesKHR(g_PhysDevice, &planeCount, planeProps);
		if (ret != VK_SUCCESS) {
			printf("error: vkGetPhysicalDeviceDisplayPlanePropertiesKHR failed.\n");
			free(planeProps);
			free(modeProps);
			free(dispProps);
			return ret;
		}

		// get supported displays for each plane
		uint32_t plane = 0;
		for (plane = 0; plane < planeCount && find == false; plane++) {
			if ((planeProps[plane].currentDisplay != VK_NULL_HANDLE) &&
				(planeProps[plane].currentDisplay != dispProps[g_ConnectorIndex].display)) {
				continue;
			}

			uint32_t supportedCount = 0;
			ret = fn_vkGetDisplayPlaneSupportedDisplaysKHR(g_PhysDevice, plane, &supportedCount, NULL);
			if (ret != VK_SUCCESS) {
				printf("error: vkGetDisplayPlaneSupportedDisplaysKHR failed.\n");
				free(planeProps);
				free(modeProps);
				free(dispProps);
				return ret;
			}

			supportedDisplays = (VkDisplayKHR *)malloc(supportedCount * sizeof(VkDisplayKHR));
			assert(supportedDisplays != (VkDisplayKHR *)NULL);

			ret = fn_vkGetDisplayPlaneSupportedDisplaysKHR(g_PhysDevice, plane, &supportedCount, supportedDisplays);
			if (ret != VK_SUCCESS) {
				printf("error: vkGetDisplayPlaneSupportedDisplaysKHR failed.\n");
				free(supportedDisplays);
				free(planeProps);
				free(modeProps);
				free(dispProps);
				return ret;
			}

			for (i = 0; i < supportedCount; i++) {
				if (dispProps[g_ConnectorIndex].display == supportedDisplays[i]) {
					// choose the plane index
					if (g_PlaneIndex == -1 && planeProps[plane].currentStackIndex == 0) {
						planeIndex = plane;
						find = true;
					}
					else if (g_PlaneIndex > -1 && planeProps[plane].currentStackIndex > 0) {
						if (g_PlaneIndex == localIndex) {
							planeIndex = plane;
							find = true;
						}
						localIndex++;
					}
					break;
				}
			}

			free(supportedDisplays);
		}

		free(planeProps);

		if (!find) {
			printf("plane is not found.\n");
			free(modeProps);
			free(dispProps);
			return VK_NOT_READY;
		}

		printf("Chosen Plane index        : %u\n", planeIndex);
	}

	free(dispProps);

	surfaceCreateInfo.displayMode = modeProps[displayModeIndex].displayMode;
	surfaceCreateInfo.imageExtent = modeProps[displayModeIndex].parameters.visibleRegion;
	surfaceCreateInfo.planeIndex  = planeIndex;

	ret = fn_vkCreateDisplayPlaneSurfaceKHR(g_Instance, &surfaceCreateInfo, NULL, &g_Surface);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateDisplayPlaneSurfaceKHR failed.\n");
		free(modeProps);
		return ret;
	}

	free(modeProps);

	// check surface support present
	{
		int i;
		VkBool32 *supportPresent = (VkBool32 *)malloc(g_QueueFamilyCount * sizeof(VkBool32));
		for (i = 0; i < g_QueueFamilyCount; i++) {
			ret = vkGetPhysicalDeviceSurfaceSupportKHR(g_PhysDevice, i, g_Surface, &supportPresent[i]);
			if (ret != VK_SUCCESS) {
				printf("error: vkGetPhysicalDeviceSurfaceSupportKHR failed.\n");
				free(supportPresent);
				return ret;
			}
		}
		if (supportPresent[g_GraphicsFamilyIndex] != VK_TRUE) {
			printf("error: This physical device could not support a surface.\n");
			free(supportPresent);
			return ret;
		}
		free(supportPresent);
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateSwapchain
 * Description    : Create Swapchain
 *****************************************************************************/
VkResult CreateSwapchain(void)
{
	VkSurfaceFormatKHR *surfaceFormat;
	VkSurfaceCapabilitiesKHR surfaceCapabilities;
	VkPresentModeKHR myPresentMode = VK_PRESENT_MODE_FIFO_KHR;
	VkSurfaceTransformFlagBitsKHR mySurfaceTransformFlag = VK_SURFACE_TRANSFORM_IDENTITY_BIT_KHR;
	VkPresentModeKHR *presentMode;
	uint32_t queueFamily = 0;
	uint32_t swapChainImageCount = 0;
	VkSwapchainCreateInfoKHR swapchainCreate = {
		.sType                 = VK_STRUCTURE_TYPE_SWAPCHAIN_CREATE_INFO_KHR,
		.pNext                 = NULL,
		.flags                 = 0,
		.surface               = g_Surface,
		.minImageCount         = 0,
		.imageFormat           = IMAGE_FORMAT,
		.imageColorSpace       = COLOR_SPACE,
		.imageExtent           = { 0 },
		.imageArrayLayers      = 1,
		.imageUsage            = VK_IMAGE_USAGE_COLOR_ATTACHMENT_BIT,
		.imageSharingMode      = VK_SHARING_MODE_EXCLUSIVE,
		.queueFamilyIndexCount = 1,
		.pQueueFamilyIndices   = &queueFamily,
		.preTransform          = 0,
		.compositeAlpha        = VK_COMPOSITE_ALPHA_OPAQUE_BIT_KHR,
		.presentMode           = 0,
		.clipped               = VK_FALSE,
		.oldSwapchain          = VK_NULL_HANDLE};
	uint32_t count, i;
	VkResult ret;

	count = 0;
	ret = fn_vkGetPhysicalDeviceSurfaceFormatsKHR(g_PhysDevice, g_Surface, &count, NULL);
	if ((ret != VK_SUCCESS) || (count < 1)) {
		printf("error: vkGetPhysicalDeviceSurfaceFormatsKHR failed.\n");
		return ret;
	}

	printf("Display Format Count      : %d\n", count);

	surfaceFormat = (VkSurfaceFormatKHR *)malloc(count * sizeof(VkSurfaceFormatKHR));
	assert(surfaceFormat != (VkSurfaceFormatKHR *)NULL);

	ret = fn_vkGetPhysicalDeviceSurfaceFormatsKHR(g_PhysDevice, g_Surface, &count, surfaceFormat);
	if (ret != VK_SUCCESS) {
		printf("error: vkGetPhysicalDeviceSurfaceFormatsKHR failed.\n");
		free(surfaceFormat);
		return ret;
	}

	for (i = 0; i < count; i++) {
		if ((surfaceFormat[i].format == IMAGE_FORMAT) && (surfaceFormat[i].colorSpace == COLOR_SPACE)) {
			break;
		}
	}

	if (i >= count) {
		printf("error: unknown imageformat/colorspace(imageformat = %d, colorspace = %d)\n",
			   surfaceFormat[0].format,
			   surfaceFormat[0].colorSpace);
	}

	ret = fn_vkGetPhysicalDeviceSurfaceCapabilitiesKHR(g_PhysDevice, g_Surface, &surfaceCapabilities);
	if (ret != VK_SUCCESS) {
		printf("error: vkGetPhysicalDeviceSurfaceCapabilitiesKHR failed.\n");
		free(surfaceFormat);
		return ret;
	}

	if (!(surfaceCapabilities.supportedTransforms & mySurfaceTransformFlag)) {
		mySurfaceTransformFlag = surfaceCapabilities.supportedTransforms;
	}

	swapChainImageCount = surfaceCapabilities.minImageCount + 1;
	if (   (surfaceCapabilities.maxImageCount > 0)
		&& (swapChainImageCount > surfaceCapabilities.maxImageCount)) {
		swapChainImageCount = surfaceCapabilities.maxImageCount;
	}

	if (swapChainImageCount > COMMAND_BUFFER_MAX) {
		swapChainImageCount = COMMAND_BUFFER_MAX; // maybe, resources of the buffer is not enough.
	}

	count = 0;
	ret = fn_vkGetPhysicalDeviceSurfacePresentModesKHR(g_PhysDevice, g_Surface, &count, NULL);
	if ((ret != VK_SUCCESS) || (count < 1)) {
		printf("error: vkGetPhysicalDeviceSurfacePresentModesKHR failed.\n");
		free(surfaceFormat);
		return ret;
	}

	printf("Display Present Mode Count: %d\n", count);

	presentMode = (VkPresentModeKHR *)malloc(count * sizeof(VkPresentModeKHR));
	assert(presentMode != (VkPresentModeKHR *)NULL);

	ret =  fn_vkGetPhysicalDeviceSurfacePresentModesKHR(g_PhysDevice, g_Surface, &count, presentMode);
	if (ret != VK_SUCCESS) {
		printf("error: vkGetPhysicalDeviceSurfacePresentModesKHR failed.\n");
		free(surfaceFormat);
		free(presentMode);
		return ret;
	}

	for (i = 0; i < count; i++) {
		if (presentMode[i] == g_PresentMode) {
			myPresentMode = presentMode[i];
			break;
		}
	}
	switch (myPresentMode) {
	default:
	case VK_PRESENT_MODE_IMMEDIATE_KHR:
		myPresentMode = VK_PRESENT_MODE_IMMEDIATE_KHR;
		printf("Present Mode              : VK_PRESENT_MODE_IMMEDIATE_KHR\n");
		break;
	case VK_PRESENT_MODE_MAILBOX_KHR:
		printf("Present Mode              : VK_PRESENT_MODE_MAILBOX_KHR\n");
		break;
	case VK_PRESENT_MODE_FIFO_KHR:
		printf("Present Mode              : VK_PRESENT_MODE_FIFO_KHR\n");
		break;
	case VK_PRESENT_MODE_FIFO_RELAXED_KHR:
		printf("Present Mode              : VK_PRESENT_MODE_FIFO_RELAXED_KHR\n");
		break;
 	}
	free(presentMode);

	if (surfaceCapabilities.currentExtent.width == -1 || surfaceCapabilities.currentExtent.height == -1) {
		if (g_PlaneExtent.width == 0 || g_PlaneExtent.height == 0 ||
		    g_PlaneExtent.width > surfaceCapabilities.maxImageExtent.width ||
		    g_PlaneExtent.height > surfaceCapabilities.maxImageExtent.height) {
			g_PlaneExtent = surfaceCapabilities.maxImageExtent;
		}

		if (g_PlaneIndex == -1) {
			g_PlaneExtent = surfaceCapabilities.maxImageExtent;
		}
	}
	else {
		g_PlaneExtent = surfaceCapabilities.currentExtent;
	}

	swapchainCreate.minImageCount   = swapChainImageCount;
	swapchainCreate.imageExtent     = g_PlaneExtent;
	swapchainCreate.preTransform    = mySurfaceTransformFlag;
	swapchainCreate.presentMode     = myPresentMode;
	ret = fn_vkCreateSwapchainKHR(g_Device, &swapchainCreate, NULL, &g_Swapchain);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateSwapchainKHR failed.\n");
		free(surfaceFormat);
		return ret;
	}

	printf("Surface Size              : %u x %u\n", g_PlaneExtent.width, g_PlaneExtent.height);

	free(surfaceFormat);

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroySurface
 * Description    : Destroy Surface
 *****************************************************************************/
void DestroySurface(void)
{
	if (g_Surface == NULL) return;

	fn_vkDestroySurfaceKHR(g_Instance, g_Surface, NULL);
	g_Surface = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroySwapchain
 * Description    : Destroy Swapchain
 *****************************************************************************/
void DestroySwapchain(void)
{
	if (g_Swapchain == NULL) return;

	fn_vkDestroySwapchainKHR(g_Device, g_Swapchain, NULL);
	g_Swapchain = NULL;

	return;
}
