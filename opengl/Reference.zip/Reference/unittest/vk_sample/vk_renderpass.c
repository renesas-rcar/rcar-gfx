/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_renderpass.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
VkRenderPass g_RenderPass = NULL;

/*****************************************************************************
 * Function Name  : CreateRenderPass
 * Description    : Create Render Pass
 *****************************************************************************/
VkResult CreateRenderPass(void)
{
	VkAttachmentDescription attachmentDesc[2] = {
		{
			.format         = IMAGE_FORMAT,
			.samples        = VK_SAMPLE_COUNT_1_BIT,
			.loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR,
			.storeOp        = VK_ATTACHMENT_STORE_OP_STORE,
			.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
			.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,
			.initialLayout  = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
			.finalLayout    = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL,
			.flags          = 0
		},
		{
			.format         = DEPTH_FORMAT,
			.samples        = VK_SAMPLE_COUNT_1_BIT,
			.loadOp         = VK_ATTACHMENT_LOAD_OP_CLEAR,
			.storeOp        = VK_ATTACHMENT_STORE_OP_DONT_CARE,
			.stencilLoadOp  = VK_ATTACHMENT_LOAD_OP_DONT_CARE,
			.stencilStoreOp = VK_ATTACHMENT_STORE_OP_DONT_CARE,


			.initialLayout  = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
			.finalLayout    = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL,
			.flags          = 0
		}
	};
	VkAttachmentReference attachmentRef[2] = {
		{
			.attachment = 0,
			.layout     = VK_IMAGE_LAYOUT_COLOR_ATTACHMENT_OPTIMAL
		},
		{
			.attachment = 1,
			.layout     = VK_IMAGE_LAYOUT_DEPTH_STENCIL_ATTACHMENT_OPTIMAL
		}
	};
	VkSubpassDescription subpassDesc = {
		.pipelineBindPoint       = VK_PIPELINE_BIND_POINT_GRAPHICS,
		.flags                   = 0,
		.inputAttachmentCount    = 0,
		.pInputAttachments       = NULL,
		.colorAttachmentCount    = 1,
		.pColorAttachments       = &attachmentRef[0],
		.pResolveAttachments     = NULL,
		.pDepthStencilAttachment = &attachmentRef[1],
		.preserveAttachmentCount = 0,
		.pPreserveAttachments    = NULL};
	VkRenderPassCreateInfo rpCreateInfo = {
		.sType           = VK_STRUCTURE_TYPE_RENDER_PASS_CREATE_INFO,
		.pNext           = NULL,
		.flags           = 0,
		.attachmentCount = 2,
		.pAttachments    = attachmentDesc,
		.subpassCount    = 1,
		.pSubpasses      = &subpassDesc,
		.dependencyCount = 0,
		.pDependencies   = NULL};
	VkResult ret;

	ret = vkCreateRenderPass(g_Device, &rpCreateInfo, NULL, &g_RenderPass);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateRenderPass failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroyRenderPass
 * Description    : Destroy Render Pass
 *****************************************************************************/
void DestroyRenderPass(void)
{
	if (g_RenderPass == NULL) return;

	vkDestroyRenderPass(g_Device, g_RenderPass, NULL);
	g_RenderPass = NULL;

	return;
}
