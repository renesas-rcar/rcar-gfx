/*************************************************************************/ /*!
@Copyright      Copyright (c) Imagination Technologies Ltd. All Rights Reserved
@License        Dual MIT/GPLv2

The contents of this file are subject to the MIT license as set out below.

Permission is hereby granted, free of charge, to any person obtaining a copy
of this software and associated documentation files (the "Software"), to deal
in the Software without restriction, including without limitation the rights
to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
copies of the Software, and to permit persons to whom the Software is
furnished to do so, subject to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

Alternatively, the contents of this file may be used under the terms of
the GNU General Public License Version 2 ("GPL") in which case the provisions
of GPL are applicable instead of those above.

If you wish to allow use of your version of this file only under the terms of
GPL, and not to allow others to use your version of this file under the terms
of the MIT license, indicate your decision by deleting the provisions above
and replace them with the notice and other provisions required by GPL as set
out in the file called "GPL-COPYING" included in this distribution. If you do
not delete the provisions above, a recipient may use your version of this file
under the terms of either the MIT license or GPL.

This License is also included in this distribution in the file called
"MIT-COPYING".

EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.

@Copyright      Portions Copyright (c) Synopsys Ltd. All Rights Reserved
@License        Synopsys Permissive License

The Synopsys Software Driver and documentation (hereinafter "Software")
is an unsupported proprietary work of Synopsys, Inc. unless otherwise
expressly agreed to in writing between  Synopsys and you.

The Software IS NOT an item of Licensed Software or Licensed Product under
any End User Software License Agreement or Agreement for Licensed Product
with Synopsys or any supplement thereto.  Permission is hereby granted,
free of charge, to any person obtaining a copy of this software annotated
with this license and the Software, to deal in the Software without
restriction, including without limitation the rights to use, copy, modify,
merge, publish, distribute, sublicense, and/or sell copies of the Software,
and to permit persons to whom the Software is furnished to do so, subject
to the following conditions:

The above copyright notice and this permission notice shall be included in
all copies or substantial portions of the Software.

THIS SOFTWARE IS BEING DISTRIBUTED BY SYNOPSYS SOLELY ON AN "AS IS" BASIS
AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
ARE HEREBY DISCLAIMED. IN NO EVENT SHALL SYNOPSYS BE LIABLE FOR ANY DIRECT,
INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES
(INCLUDING, BUT NOT     LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR
SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH
DAMAGE.

*/ /**************************************************************************/

#ifndef HDMI_H
#define HDMI_H

#include "img_types.h"
#include "img_defs.h"
#include "pvrsrv_error.h"
#include "hdmi_regs.h"
#include "pvrsrv.h"
#include "powervr/imgpixfmts.h"
#include "dc_osfuncs.h"
#include "plato.h"

#include <linux/interrupt.h>
#include <linux/irq.h>


#define DRVNAME	"plato_hdmi"
#define HDMI_MAX_COMMANDS_INFLIGHT    (2)

typedef PVRSRV_ERROR (*PFN_PDP_INIT)(VIDEO_PARAMS * pVideoParams, IMG_UINT32 uiInstance);

/*************************************************************************/ /*!
 PCI Device Information
*/ /**************************************************************************/

// See sysinfo.h

/*************************************************************************/ /*!
 HDMI data structures
*/ /**************************************************************************/

typedef struct HDMI_MODULE_PARAMETERS_TAG
{
	IMG_UINT32	ui32HDMIEnabled;
} HDMI_MODULE_PARAMETERS;

const HDMI_MODULE_PARAMETERS *HDMIGetModuleParameters(void);

typedef struct HDMI_DEVICE
{
	IMG_HANDLE                  hPVRServicesConnection;
	IMG_HANDLE                  hPVRServicesDevice;
	IMG_HANDLE                  hLISRData;
	DC_SERVICES_FUNCS           sPVRServicesFuncs;
	DC_SPINLOCK                 irqLock;
	struct delayed_work         delayedWork;
	void                        *pvDevice;

	IMG_CPU_PHYADDR             sHDMIRegCpuPAddr;
	IMG_CPU_VIRTADDR            pvHDMIRegCpuVAddr;

	IMG_CPU_PHYADDR             sTopRegCpuPAddr;
	IMG_CPU_VIRTADDR            pvTopRegCpuVAddr;

	VIDEO_PARAMS                videoParams;

	IMG_BOOL                    mInitialized;
	IMG_BOOL                    bHPD;

	/* Callback for PDP */
	PFN_PDP_INIT                pfnPDPInitialize;

	/* Plato core and PLL clock speeds */
	IMG_UINT32                  ui32CoreClockSpeed;
	IMG_UINT32                  ui32PLLClockSpeed;

	/* Doubly linked list of device units */
	DLLIST_NODE                 sListNode;
	struct dentry               *psDebugFSEntryDir;     /* 'plato_hdmi' entry */
	struct dentry               *psDisplayEnabledEntry; /* 'display_enabled' entry */
	IMG_UINT32                  ui32Instance;           /* device instance */
	IMG_BOOL                    bHDMIEnabled;           /* state of 'display_enabled' */
} HDMI_DEVICE;


/*******************************************************************************
 * HDMI common functions
 ******************************************************************************/

PVRSRV_ERROR HDMIDrvInit(void *pvDevice, HDMI_DEVICE **ppsDeviceData);
void HDMIDrvDeInit(HDMI_DEVICE *psDeviceData);

/*******************************************************************************
 * Debug/print macros
 ******************************************************************************/
#if defined(PLATO_DISPLAY_PDUMP)
#include "plato_pdump.h"

static void HDMIPdumpReg32(void *pvLinRegBaseAddr, IMG_UINT32 ui32Offset, IMG_UINT32 ui32Value)
{
	OSWriteHWReg32(pvLinRegBaseAddr,  ui32Offset,  ui32Value);
	plato_pdump_reg32(pvLinRegBaseAddr, ui32Offset, ui32Value, DRVNAME);
}

#undef DC_OSWriteReg32

#define DC_OSWriteReg32 HDMIPdumpReg32

#define polpr(base,reg,val,msk,cnt,intrvl) \
	plato_pdump_pol(base,reg,val,msk, DRVNAME); \
	do { \
		IMG_UINT32 polnum; \
		for (polnum = 0; polnum < cnt; polnum++) \
		{ \
			if ((DC_OSReadReg32(base, reg) & msk) == val) \
			{ \
				break; \
			} \
			DC_OSDelayus(intrvl * 1000); \
		} \
		if (polnum == cnt) \
		{ \
			HDMI_DEBUG_PRINT(" Poll failed for register: 0x%08X", (unsigned int)reg); \
		} \
	} while (0)
#else
#define polpr(base,reg,val,msk,cnt,intrvl) \
	do { \
		IMG_UINT32 polnum; \
		for (polnum = 0; polnum < cnt; polnum++) \
		{ \
			if ((DC_OSReadReg32(base, reg) & msk) == val) \
			{ \
				break; \
			} \
			DC_OSDelayus(intrvl * 1000); \
		} \
		if (polnum == cnt) \
		{ \
			HDMI_DEBUG_PRINT(" Poll failed for register: 0x%08X", (unsigned int)reg); \
		} \
	} while (0)
#endif // PLATO_DISPLAY_PDUMP


#define HDMI_REG_POLL(base,reg,val,msk) polpr(base,reg*4,val,msk,10,10)
#define TOP_REG_POLL(base,reg,val,msk) polpr(base,reg,val,msk,10,10)


#define CHECK_AND_EXIT(status, label) if (status != PVRSRV_OK) goto label;
#define IS_BIT_SET(value, bit) (value & (1 << bit))

#if !defined(VIRTUAL_PLATFORM)
#if defined(HDMI_DEBUG)
	#define HDMI_CHECKPOINT HDMI_DEBUG_PRINT(" CP: - %s, line %d\n", __func__, __LINE__);
	#define HDMI_DEBUG_PRINT(fmt, ...) \
		DC_OSDebugPrintf(DBGLVL_INFO, fmt, __VA_ARGS__)

	#define HDMI_WRITE_CORE_REG(base, offset, value) \
		DC_OSWriteReg32(base, offset * 4, value);

#else
	#define HDMI_CHECKPOINT
	#define HDMI_DEBUG_PRINT(fmt, ...)
	#define HDMI_WRITE_CORE_REG(base, offset, value) DC_OSWriteReg32(base, offset * 4, value);
#endif

#define HDMI_READ_CORE_REG(base, offset) DC_OSReadReg32(base, offset * 4)
#define HDMI_READ_MOD_WRITE(base, offset, value) HDMI_WRITE_CORE_REG(base, offset, (HDMI_READ_CORE_REG(base,offset) | value))
#else /* VIRTUAL_PLATFORM */

#define HDMI_CHECKPOINT HDMI_DEBUG_PRINT(" CP: - %s, line %d\n", __func__, __LINE__);
#define HDMI_DEBUG_PRINT(fmt, ...) \
	DC_OSDebugPrintf(DBGLVL_INFO, fmt, __VA_ARGS__)
#define HDMI_WRITE_CORE_REG(base, offset, value)
#define HDMI_READ_CORE_REG(base, offset) (0)
#define HDMI_READ_MOD_WRITE(base, offset, value)

#endif

#define HDMI_ERROR_PRINT(fmt, ...) \
	DC_OSDebugPrintf(DBGLVL_ERROR, fmt, __VA_ARGS__)

#define HDMI_LOG_ALWAYS(fmt, ...) \
	DC_OSDebugPrintf(DBGLVL_INFO, fmt, __VA_ARGS__)

#endif
