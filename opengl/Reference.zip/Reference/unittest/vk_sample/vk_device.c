/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_device.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2016.9.14
//            - Change VK_API_VERSION to VK_API_VERSION_1_0
//          : 2017.1.5
//            - Add the debug log for vkGetPhysicalDeviceDisplayPropertiesKHR.
//            - Add the debug log for vkGetDisplayModePropertiesKHR.
//          : 2017.10.31
//            - Add a check on the supported surface.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <assert.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  DEFINES
 ****************************************************************************/
#define APPLICATION_NAME    "vk_sample"
#define ENGINE_NAME         "vk_sample_engine"
#define APPLICATION_VERSION VK_MAKE_VERSION(1, 0, 2)
#define ENGINE_VERSION      VK_MAKE_VERSION(1, 0, 0)

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
VkInstance g_Instance = NULL;
VkPhysicalDevice g_PhysDevice = NULL;
VkPhysicalDeviceMemoryProperties g_PhysMemoryProps = { 0 };
VkPhysicalDeviceProperties g_PhysDeviceProps = { 0 };
VkDevice g_Device = NULL;

VkQueue g_GraphicsQueue = NULL;
uint32_t g_GraphicsFamilyIndex = 0;
uint32_t g_QueueFamilyCount = 0;

VkResult checkValidationLayerSupport() {
    uint32_t layerCount;
	VkResult ret = -1;

    ret = vkEnumerateInstanceLayerProperties(&layerCount, NULL);
	if (ret != VK_SUCCESS) {
        printf("Failed to get the number of supported layers.\n");
        vkDestroyInstance(g_Instance, NULL);
        return ret;
    }

    VkLayerProperties *availableLayers = (VkLayerProperties*) malloc (layerCount * sizeof(VkLayerProperties));
    ret = vkEnumerateInstanceLayerProperties(&layerCount, availableLayers);
	if (ret != VK_SUCCESS) {
        printf("Failed to get the list of supported layers.\n");
        free(availableLayers);
        vkDestroyInstance(g_Instance, NULL);
        return ret;
    }

	printf("Layer Count: %d.\n", layerCount);
    for (uint32_t i = 0; i < layerCount; i++) {
        printf("Layer Name: %s.\n", availableLayers[i].layerName);
    }

	return VK_SUCCESS;
}
/*****************************************************************************
 * Function Name  : CreateInstance
 * Description    : Create Instance 
 *****************************************************************************/
VkResult CreateInstance(void)
{
	const char* instanceExtensions[] = {
		VK_KHR_SURFACE_EXTENSION_NAME,
		VK_KHR_DISPLAY_EXTENSION_NAME
	};
	uint32_t instanceExtensionCount = 2;
	const char* validationLayers = {
		"VK_LAYER_KHRONOS_validation"
	};
	VkApplicationInfo appInfo = {
		.sType                   = VK_STRUCTURE_TYPE_APPLICATION_INFO,
		.pNext                   = NULL,
		.pApplicationName        = APPLICATION_NAME,
		.applicationVersion      = APPLICATION_VERSION,
		.pEngineName             = ENGINE_NAME,
		.engineVersion           = ENGINE_VERSION,
		.apiVersion              = VK_API_VERSION_1_3};
	VkInstanceCreateInfo instanceInfo = {
		.sType                   = VK_STRUCTURE_TYPE_INSTANCE_CREATE_INFO,
		.pNext                   = NULL,
		.flags                   = 0,
		.pApplicationInfo        = &appInfo,
		.ppEnabledLayerNames     = NULL,
		.enabledExtensionCount   = instanceExtensionCount,
		.ppEnabledExtensionNames = instanceExtensions};
	VkResult ret;

	/* Creating a VkInstance object */
	ret = vkCreateInstance(&instanceInfo, NULL, &g_Instance);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateInstance failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : EnumeratePhysicalDevices
 * Description    : Enumerate Physical Device
 *****************************************************************************/
VkResult EnumeratePhysicalDevices(void)
{
	uint32_t count;
	VkResult ret;

	count = 0;
	/* number of physical devices available */
	ret = vkEnumeratePhysicalDevices(g_Instance, &count, NULL);
	if ((ret != VK_SUCCESS) || (count < 1)) {
		printf("error: vkEnumeratePhysicalDevices failed.\n");
		return ret;
	}

	printf("Physical Device Count     : %d\n", count);

	count = 1; /* use first physical device */
	ret = vkEnumeratePhysicalDevices(g_Instance, &count, &g_PhysDevice);
	if (ret != VK_SUCCESS) {
		printf("error: vkEnumeratePhysicalDevices failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/* DeviceType string */
static char *DeviceTypeToStr(enum VkPhysicalDeviceType type)
{
	switch(type) {
	case VK_PHYSICAL_DEVICE_TYPE_OTHER:
		return "VK_PHYSICAL_DEVICE_TYPE_OTHER";
	case VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU:
		return "VK_PHYSICAL_DEVICE_TYPE_INTEGRATED_GPU";
	case VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU:
		return "VK_PHYSICAL_DEVICE_TYPE_DISCRETE_GPU";
	case VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU:
		return "VK_PHYSICAL_DEVICE_TYPE_VIRTUAL_GPU";
	case VK_PHYSICAL_DEVICE_TYPE_CPU:
		return "VK_PHYSICAL_DEVICE_TYPE_CPU";
	default:
		break;
	}

	return "UnknownDeviceType";
}

/*****************************************************************************
 * Function Name  : GetPhysicalDeviceProperties
 * Description    : Get Physical Device Properties and Memory Properties
 *****************************************************************************/
VkResult GetPhysicalDeviceProperties(void)
{
	/* general properties of the physical devices */
	vkGetPhysicalDeviceProperties(g_PhysDevice, &g_PhysDeviceProps);
	vkGetPhysicalDeviceMemoryProperties(g_PhysDevice, &g_PhysMemoryProps);

	printf("DeviceProperties:\n");
	printf(" PhysicalDevice Name      : %s\n", g_PhysDeviceProps.deviceName);
	printf(" Driver Version           : %d\n", g_PhysDeviceProps.driverVersion);
	printf(" Vendor ID                : %d\n", g_PhysDeviceProps.vendorID);
	printf(" Device ID                : %d\n", g_PhysDeviceProps.deviceID);
	printf(" API Version              : %d.%d.%d\n",
		   (g_PhysDeviceProps.apiVersion >> 22) & 0x03ff,
		   (g_PhysDeviceProps.apiVersion >> 12) & 0x03ff,
		   (g_PhysDeviceProps.apiVersion & 0x0fff));
	printf(" Device Type              : %s\n",
		   DeviceTypeToStr(g_PhysDeviceProps.deviceType));
	printf("DeviceMemoryProperties:\n");
	printf(" Memory Type Count        : %d\n", g_PhysMemoryProps.memoryTypeCount);
	printf(" Heap Count               : %d\n", g_PhysMemoryProps.memoryHeapCount);
	
	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateDevice
 * Description    : Create Device and Queue
 *****************************************************************************/
VkResult CreateDeviceAndQueue(void)
{
	VkQueueFamilyProperties *familyProps = NULL;
	float queuePriorities[1];
	const char* deviceExtensions[] = {
		VK_KHR_SWAPCHAIN_EXTENSION_NAME
	};
	uint32_t deviceExtensionCount = 1;
	VkDeviceQueueCreateInfo queueInfo = {
		.sType                   = VK_STRUCTURE_TYPE_DEVICE_QUEUE_CREATE_INFO,
		.pNext                   = NULL,
		.flags                   = 0,
		.queueCount              = 1,
		.queueFamilyIndex        = 0,
		.pQueuePriorities        = &queuePriorities[0]};
	VkDeviceCreateInfo deviceInfo = {
		.sType                   = VK_STRUCTURE_TYPE_DEVICE_CREATE_INFO,
		.pNext                   = NULL,
		.queueCreateInfoCount    = 1,
		.pQueueCreateInfos       = &queueInfo,
		.enabledLayerCount       = 0,
		.ppEnabledLayerNames     = NULL,
		.enabledExtensionCount   = deviceExtensionCount,
		.ppEnabledExtensionNames = deviceExtensions,
		.pEnabledFeatures        = NULL};
	uint32_t i;
	VkResult ret;

	/* number of queues properties available */
	g_QueueFamilyCount = 0;
	vkGetPhysicalDeviceQueueFamilyProperties(g_PhysDevice, &g_QueueFamilyCount, NULL);
	if (g_QueueFamilyCount < 1) {
		printf("error: vkGetPhysicalDeviceQueueFamilyProperties failed.\n");
		return VK_INCOMPLETE;
	}

	familyProps = (VkQueueFamilyProperties *)malloc(g_QueueFamilyCount * sizeof(VkQueueFamilyProperties));
	assert(familyProps != (VkQueueFamilyProperties *)NULL);

	vkGetPhysicalDeviceQueueFamilyProperties(g_PhysDevice, &g_QueueFamilyCount, familyProps);

	/* check capabilities of the queues in this queue family */
	g_GraphicsFamilyIndex = UINT32_MAX;
	for (i = 0; i < g_QueueFamilyCount; i++) {
		if (familyProps[i].queueFlags & VK_QUEUE_GRAPHICS_BIT) {
			g_GraphicsFamilyIndex = i;
			break;
		}
	}

	if (g_GraphicsFamilyIndex == UINT32_MAX) {
		printf("error: Could not find a graphics queue.\n");
		free(familyProps);
		return VK_INCOMPLETE;
	}

	queuePriorities[0]         = 0.0f;
	queueInfo.queueFamilyIndex = g_GraphicsFamilyIndex;

	ret = vkCreateDevice(g_PhysDevice, &deviceInfo, NULL, &g_Device);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateDevice failed.\n");
		free(familyProps);
		return ret;
	}

	vkGetDeviceQueue(g_Device, g_GraphicsFamilyIndex, 0, &g_GraphicsQueue);
	free(familyProps);
	(void)checkValidationLayerSupport();

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DeviceWaitIdle
 * Description    : Wait idle for all queues owned by device
 *****************************************************************************/
VkResult DeviceWaitIdle(void)
{
	VkResult ret;

	ret = vkDeviceWaitIdle(g_Device);
	if (ret != VK_SUCCESS) {
		printf("error: vkDeviceWaitIdle failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroyInstance
 * Description    : Destroy Instance 
 *****************************************************************************/
void DestroyInstance(void)
{
	if (g_Instance == NULL) return;

	vkDestroyInstance(g_Instance, NULL);
	g_Instance = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroyDevice
 * Description    : Destroy Device
 *****************************************************************************/
void DestroyDevice(void)
{
	if (g_Device == NULL) return;

	vkDestroyDevice(g_Device, NULL);
	g_Device = NULL;

	return;
}
