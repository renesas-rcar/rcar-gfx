/*
 * @File
 * @Codingstyle LinuxKernel
 * @Copyright   Copyright (c) Imagination Technologies Ltd. All Rights Reserved
 * @License     Dual MIT/GPLv2
 *
 * The contents of this file are subject to the MIT license as set out below.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * Alternatively, the contents of this file may be used under the terms of
 * the GNU General Public License Version 2 ("GPL") in which case the provisions
 * of GPL are applicable instead of those above.
 *
 * If you wish to allow use of your version of this file only under the terms of
 * GPL, and not to allow others to use your version of this file under the terms
 * of the MIT license, indicate your decision by deleting the provisions above
 * and replace them with the notice and other provisions required by GPL as set
 * out in the file called "GPL-COPYING" included in this distribution. If you do
 * not delete the provisions above, a recipient may use your version of this file
 * under the terms of either the MIT license or GPL.
 *
 * This License is also included in this distribution in the file called
 * "MIT-COPYING".
 *
 * EXCEPT AS OTHERWISE STATED IN A NEGOTIATED AGREEMENT: (A) THE SOFTWARE IS
 * PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED, INCLUDING
 * BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A PARTICULAR
 * PURPOSE AND NONINFRINGEMENT; AND (B) IN NO EVENT SHALL THE AUTHORS OR
 * COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER
 * IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN
 * CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

#if !defined(__PVR_EXPORT_FENCES_H__)
#define __PVR_EXPORT_FENCES_H__

#include "pvr_linux_fence.h"
#include "services_kernel_client.h"

struct pvr_exp_fence_context;
struct pvr_exp_fence;

enum export_fence_resolve_type {
	EXPORT_FENCE_RESOLVE_FOR_CHECK,
	EXPORT_FENCE_RESOLVE_FOR_UPDATE
};

struct pvr_exp_fence_context *pvr_exp_fence_context_create(const char *name,
				const char *driver_name);
void pvr_exp_fence_context_destroy(struct pvr_exp_fence_context *fence_context);
struct dma_fence *pvr_exp_fence_create(struct pvr_exp_fence_context *fence_context,
				       int fd,
				       u64 *sync_pt_idx);

const char *pvr_exp_fence_context_name(struct pvr_exp_fence_context *fctx);
void pvr_exp_fence_context_value_str(struct pvr_exp_fence_context *fctx,
				    char *str, int size);

enum PVRSRV_ERROR_TAG pvr_exp_fence_assign_checkpoint(PVRSRV_FENCE fence_to_resolve,
						      struct dma_fence *fence,
						      enum export_fence_resolve_type resolve_use,
						      PSYNC_CHECKPOINT_CONTEXT checkpoint_context,
						      PSYNC_CHECKPOINT *assigned_checkpoint);

enum PVRSRV_ERROR_TAG pvr_exp_fence_rollback(struct dma_fence *fence);

enum PVRSRV_ERROR_TAG pvr_exp_fence_finalise(struct dma_fence *fence);

bool pvr_is_exp_fence(struct dma_fence *fence);

struct pvr_exp_fence *to_pvr_exp_fence(struct dma_fence *fence);

struct SYNC_CHECKPOINT_TAG *
pvr_exp_fence_get_checkpoint(struct pvr_exp_fence *export_fence);

#endif /* !defined(__PVR_EXPORT_FENCES_H__) */
