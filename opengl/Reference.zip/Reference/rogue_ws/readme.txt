[Confidential]

1. TARGET SoC

   R8A779G0

2. ENVIRONMENT

   BSP            : R-Car V4H Yocto recipe package included in R-Car SDK
   ToolChain      : Toolchain included in Yocto SDK 
                    ( refer to the "Yocto recipe Start-Up Guide" provided 
                      by Yocto recipe package for detail)

3. HOW TO BUILD

   1) Set environment variables before compilation of wsegl module.
      $ source {$TARGET_DIRECTORY_FOR_SDK}/environment-setup-aarch64-poky-linux

      *)  {$TARGET_DIRECTORY_FOR_SDK} is target directory for SDK. e.g. "/opt/poky/3.1.11".

  <Using nullws_drm>
   2) Build nullws_drm module.
      $ cd $WORK/Reference/rogue_ws/nullws_rcar/client
      $ make

README.TXT / Dec 2023
