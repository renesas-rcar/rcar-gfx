/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : TriangleFS.frag
// CREATED  : 2016.4.11
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-car H3
// HISTORY  : 2016.4.11
//            - Created release code.
/****************************************************************************/
#version 450

/* Input Definitions */
layout(location = 0) in vec2 InputTexCoord;
layout(location = 1) in vec4 InputColor;

/* Output Definitions */
layout(location = 0) out vec4 OutputColor;

/*****************************************************************************
 * Function Name  : main
 * Description    : 
 *****************************************************************************/
void main()
{
	OutputColor = InputColor;
}
