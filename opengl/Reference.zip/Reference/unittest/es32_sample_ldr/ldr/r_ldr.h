#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_H

#ifdef __cplusplus
extern "C" {
#endif

#include "r_ldr_user.h"
#include "r_ldr_user_handy_func.h"
#include "r_ldr_timer.h"
#include "r_ldr_macros.h"
#include "r_ldr_user_cfg.h"

#ifdef __cplusplus
}
#endif

#endif