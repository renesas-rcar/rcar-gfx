/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_object.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
VkFence g_GraphicsFence = NULL;
VkSemaphore g_GraphicsRenderingCompleteSemaphore = NULL;
VkSemaphore g_GraphicsImageAcquireSemaphore = NULL;
VkCommandPool g_CommandPool = NULL;
VkCommandBuffer g_CommandBuffers[COMMAND_BUFFER_MAX] = { 0 };

/*****************************************************************************
 * Function Name  : CreateFence
 * Description    : Create Fence
 *****************************************************************************/
VkResult CreateFence(void)
{
	VkFenceCreateInfo fenceCreateInfo = {
		.sType = VK_STRUCTURE_TYPE_FENCE_CREATE_INFO,
		.pNext = NULL,
		.flags = 0};
	VkResult ret;

	ret = vkCreateFence(g_Device, &fenceCreateInfo, NULL, &g_GraphicsFence);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateFence failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateSemaphore
 * Description    : Create Semaphore
 *****************************************************************************/
VkResult CreateSemaphore(void)
{
	VkSemaphoreCreateInfo semaphoreCreateInfo = {
		.sType = VK_STRUCTURE_TYPE_SEMAPHORE_CREATE_INFO,
		.pNext = NULL,
		.flags = 0};
	VkResult ret;

	ret = vkCreateSemaphore(g_Device,
							&semaphoreCreateInfo, NULL, &g_GraphicsRenderingCompleteSemaphore);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateSemaphore failed.\n");
		return ret;
	}

	ret = vkCreateSemaphore(g_Device,
							&semaphoreCreateInfo, NULL, &g_GraphicsImageAcquireSemaphore);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateSemaphore failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : CreateCommandPool
 * Description    : Create Command Pool
 *****************************************************************************/
VkResult CreateCommandPool(void)
{
	VkCommandPoolCreateInfo poolInfo = {
		.sType            = VK_STRUCTURE_TYPE_COMMAND_POOL_CREATE_INFO,
		.pNext            = NULL,
		.flags            = VK_COMMAND_POOL_CREATE_RESET_COMMAND_BUFFER_BIT,
		.queueFamilyIndex = g_GraphicsFamilyIndex};
	VkResult ret;

	ret = vkCreateCommandPool(g_Device, &poolInfo, NULL, &g_CommandPool);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateCommandPool failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : AllocateCommandBuffers
 * Description    : Allocate Command Buffers
 *****************************************************************************/
VkResult AllocateCommandBuffers(void)
{
	VkCommandBufferAllocateInfo allocInfo = {
		.sType              = VK_STRUCTURE_TYPE_COMMAND_BUFFER_ALLOCATE_INFO,
		.pNext              = NULL,
		.commandPool        = g_CommandPool,
		.level              = VK_COMMAND_BUFFER_LEVEL_PRIMARY,
		.commandBufferCount = COMMAND_BUFFER_MAX};
	VkResult ret;

	ret = vkAllocateCommandBuffers(g_Device, &allocInfo, &g_CommandBuffers[0]);
	if (ret != VK_SUCCESS) {
		printf("error: vkAllocateCommandBuffers failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : DestroyFence
 * Description    : Destroy Fence
 *****************************************************************************/
void DestroyFence(void)
{
	if (g_GraphicsFence == NULL) return;

	vkDestroyFence(g_Device, g_GraphicsFence, NULL);
	g_GraphicsFence = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : DestroySemaphore
 * Description    : Destroy Semaphore
 *****************************************************************************/
void DestroySemaphore(void)
{
	if (g_GraphicsRenderingCompleteSemaphore != NULL) {
		vkDestroySemaphore(g_Device, g_GraphicsRenderingCompleteSemaphore, NULL);
		g_GraphicsRenderingCompleteSemaphore = NULL;
	}

	if (g_GraphicsImageAcquireSemaphore != NULL) {
		vkDestroySemaphore(g_Device, g_GraphicsImageAcquireSemaphore, NULL);
		g_GraphicsImageAcquireSemaphore = NULL;
	}

	return;
}

/*****************************************************************************
 * Function Name  : DestroyCommandPool
 * Description    : Destroy Command Pool
 *****************************************************************************/
void DestroyCommandPool(void)
{
	if (g_CommandPool == NULL) return;

	vkDestroyCommandPool(g_Device, g_CommandPool, NULL);
	g_CommandPool = NULL;

	return;
}

/*****************************************************************************
 * Function Name  : FreeCommandBuffers
 * Description    : Free Command Buffers
 *****************************************************************************/
void FreeCommandBuffers(void)
{
	vkFreeCommandBuffers(g_Device,
						 g_CommandPool,
						 COMMAND_BUFFER_MAX,
						 g_CommandBuffers);

	return;
}
