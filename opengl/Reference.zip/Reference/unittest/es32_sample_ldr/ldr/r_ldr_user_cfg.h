#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_CFG_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_CFG_H

#ifdef __cplusplus
extern "C" {
#endif

// *************** MEMORY MAP **********************
// Memory base addresses for different configurations
#ifdef LDR_HIL_MEMORY_MAP
    #define LDR_DRAM_BASE_ADDRESS   0x8E400000UL
#else
    #define LDR_DRAM_BASE_ADDRESS   0x5F800000UL
#endif

// Memory layout configuration
#define LDR_DRAM_TOTAL_SIZE         0x100000UL      // 1MB
#define LDR_DRAM_MAP_MASK          (LDR_DRAM_TOTAL_SIZE - 1)
#define LDR_DRAM_PAGE_SIZE          4096UL          // 4KB

// Memory partitioning (Send: 90.6%, Recv: 9.4%)
#define LDR_DRAM_SEND_SIZE          0xE6000UL       // 920KB
#define LDR_DRAM_RECV_SIZE          0x1A000UL       // 104KB

// Memory region addresses
#define LDR_DRAM_SEND_ADDRESS       LDR_DRAM_BASE_ADDRESS
#define LDR_DRAM_RECV_ADDRESS       (LDR_DRAM_BASE_ADDRESS + LDR_DRAM_SEND_SIZE)

// System paths
#define LDR_DRAM_DEVICE_PATH        "/dev/mem"
// *************** MEMORY MAP END **********************

// *************** BUFFER CONFIGURATION ****************
#define LDR_POSIX_SHM_SIZE          100000UL

#define LDR_INJECTION_ITEM_ALLOC_SIZE 30
#define LDR_INJECTION_MSG_MAX_SIZE 200

#if defined(__linux__) || defined(__QNX__)
    #define LDR_USER_BUF_MAX_SIZE       2500UL
#else
    #define LDR_USER_BUF_MAX_SIZE       1500UL
#endif

// Platform-specific context allocation
#ifdef LDR_CONFIG_FREERTOS
    #define LDR_USER_CONTEXT_ALLOC_SIZE     30
#else
    #define LDR_USER_CONTEXT_ALLOC_SIZE     500
#endif
// *************** BUFFER CONFIGURATION END ************

// *************** DEFAULT VALUES **********************
#define LDR_USER_DEFAULT_ECU_ID         "ECU1"
#define LDR_DEFAULT_ENABLE_TEE_LOGGING  0
// *************** DEFAULT VALUES END ******************

#ifdef __cplusplus
}
#endif

#endif /* RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_CFG_H */