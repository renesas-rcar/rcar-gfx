#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_MACROS_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_MACROS_H


// #define LDR_LOGGING_DISABLED 1
// LDR log functions macro wrappers, allowing to exclude logging, using macro LDR_LOGGING_DISABLED

#ifdef __cplusplus
extern "C" {
#endif

#if (LDR_LOGGING_DISABLED)

    static const LdrLogConfig default_config = { false, false, LDR_OS_TIMESTAMP };

    #if (LDR_KEEP_UNUSED_ARGS)
        #define LDR_USE_ARG(arg)
    #else
        #define LDR_USE_ARG(arg) ((void)arg)
    #endif

    #define LDR_LOG_REGISTER_APP(app_id, description)
    #define LDR_LOG_UNREGISTER_APP()
    
    #define LDR_LOG_DEFINE_CONTEXT(context) LdrLogContextPtr context
    #define LDR_LOG_REFERENCE_CONTEXT(context) extern LdrLogContextPtr context
    #define LDR_LOG_INIT_CONTEXT(context, ctx_id, description)                                                         \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(ctx_id);                                                                                           \
            LDR_USE_ARG(description);                                                                                      \
        } while (0)
    
    #define LDR_LOG_INIT_CONTEXT_LL(context, ctx_id, description, log_level)                                           \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(ctx_id);                                                                                           \
            LDR_USE_ARG(description);                                                                                      \
            LDR_USE_ARG(log_level);                                                                                        \
        } while (0)
    
    #define LDR_LOG_DECLARE_CONTEXT(context, ctx_id, description)                                                      \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(ctx_id);                                                                                           \
            LDR_USE_ARG(description);                                                                                      \
        } while (0)
    
    #define LDR_LOG_DECLARE_CONTEXT_LL(context, ctx_id, description, log_level)                                        \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(ctx_id);                                                                                           \
            LDR_USE_ARG(description);                                                                                      \
            LDR_USE_ARG(log_level);                                                                                        \
        } while (0)
    
    #define LDR_LOG_FREE_CONTEXT(context)                                                                                  \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    
    #define LDR_LOG_FATAL(context, ...)                                                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_ERROR(context, ...)                                                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_WARN(context, ...)                                                                                     \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_INFO(context, ...)                                                                                     \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_DEBUG(context, ...)                                                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_VERBOSE(context, ...)                                                                                  \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    
    #define LDR_LOG_FATAL_FL(context, ...)                                                                                 \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_ERROR_FL(context, ...)                                                                                 \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_WARN_FL(context, ...)                                                                                  \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_INFO_FL(context, ...)                                                                                  \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_DEBUG_FL(context, ...)                                                                                 \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_VERBOSE_FL(context, ...)                                                                               \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    
    #define LDR_LOG_VARIADIC(context, log_level, ...)                                                                   \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
        } while (0)
    #define LDR_LOG_VARIADIC_FL(context, log_level, file, line, ...)                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(file);                                                                                             \
            LDR_USE_ARG(line);                                                                                             \
        } while (0)
    
    #define LDR_LOG_SEQUENCE(context, ...)                                                                                 \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
        } while (0)
    #define LDR_LOG_SEQUENCE_LL(context, log_level, ...)                                                                   \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
        } while (0)
    
    #define LDR_LOG_KPI(context, kpi_name, kpi_value)                                                                      \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    #define LDR_LOG_KPI_N(context, kpi_name, kpi_value)                                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    #define LDR_LOG_KPI_F(context, kpi_name, kpi_value)                                                                    \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    
    #define LDR_LOG_KPI_LL(context, log_level, kpi_name, kpi_value)                                                        \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    #define LDR_LOG_KPI_LL_N(context, log_level, kpi_name, kpi_value)                                                      \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    #define LDR_LOG_KPI_LL_F(context, log_level, kpi_name, kpi_value)                                                      \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(kpi_name);                                                                                         \
            LDR_USE_ARG(kpi_value);                                                                                        \
        } while (0)
    
    #define LDR_LOG_EVENT(context, event_name, event_type, event_id, metadata)                                             \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(event_name);                                                                                       \
            LDR_USE_ARG(event_type);                                                                                       \
            LDR_USE_ARG(event_id);                                                                                         \
            LDR_USE_ARG(metadata);                                                                                         \
        } while (0)
    #define LDR_LOG_EVENT_LL(context, log_level, event_name, event_type, event_id, metadata)                               \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(event_name);                                                                                       \
            LDR_USE_ARG(event_type);                                                                                       \
            LDR_USE_ARG(event_id);                                                                                         \
            LDR_USE_ARG(metadata);                                                                                         \
        } while (0)

    #define LDR_LOG_SET_CONFIG(LDR_LOG_CONFIG)                                                                             \
        do                                                                                                                 \
        {                                                                                                                  \
            LDR_USE_ARG(LDR_LOG_CONFIG);                                                                                        \
        } while (0)
    
    #define LDR_LOG_GET_CONFIG() (&default_config)

    #define LDR_IF_LOG_LEVEL_ENABLED(context, log_level)                                                                   \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(log_level);                                                                                        \
        } while (0)
    
    #define LDR_FI()
    
    #define LDR_LOG_FUNCTION_ENTRY_LL(context, timer, log_level, function_name)                                            \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(timer);                                                                                            \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(function_name);                                                                                    \
        } while (0)
    
    #define LDR_LOG_FUNCTION_EXIT_LL(context, timer, log_level, function_name)                                             \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(timer);                                                                                            \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(function_name);                                                                                    \
        } while (0)
    
    #define LDR_LOG_FUNCTION_EXIT_WITH_RETURN_CODE_LL(context, timer, log_level, return_code, function_name)               \
        do                                                                                                                 \
        {                                                                                                                  \
            (void)context;                                                                                                 \
            LDR_USE_ARG(timer);                                                                                            \
            LDR_USE_ARG(log_level);                                                                                        \
            LDR_USE_ARG(function_name);                                                                                    \
        } while (0)
    
    #define LDR_LOG_TIMER_ON(default_timer) struct ldr_timer default_timer = {0}                                

    #define LDR_REGISTER_LOG_LEVEL_CHANGED_CALLBACK(context, callback)                                                     \
    do                                                                                                                 \
    {                                                                                                                  \
        (void)context;                                                                                                 \
        LDR_USE_ARG(callback);                                                                                            \
    } while (0)

    #define LDR_LOG_PREDEFINE_CONTEXT(CONTEXTID, LOG_LEVEL)                                                                                      \
    do                                                                                                                 \
    {                                                                                                                  \
        LDR_USE_ARG(CONTEXTID);                                                                                                 \
        LDR_USE_ARG(LOG_LEVEL);                                                                                                 \
    } while (0)

    #define LDR_LOG_REGISTER_SWC_INJECTION(CONTEXT, ID, CALLBACK_FUNC)                                                  \
    do                                                                                                                  \
    {                                                                                                                   \
        (void)CONTEXT;                                                                                            \
        LDR_USE_ARG(ID);                                                                                                 \
        LDR_USE_ARG(CALLBACK_FUNC);                                                                                      \
    } while (0)                                                                                                         \
    
    #define LDR_LOG_DUMP_MEM(CONTEXT, LOGLEVEL, MEM_ADDR, MEM_SIZE)                                                  \
    do                                                                                                                  \
    {                                                                                                                   \
        (void)CONTEXT;                                                                                            \
        LDR_USE_ARG(LOGLEVEL);                                                                                                 \
        LDR_USE_ARG(MEM_ADDR);                                                                                      \
        LDR_USE_ARG(MEM_SIZE);                                                                                      \
    } while (0)                                                                                                         \

#else

// Logging Enabled:


    //***************************************  API compatible with ldr_lib ver 0.60:: will be deleted soon, ****************************************************************** */

    #define LDR_LOG_REGISTER_DLT_APP(APPID, DESCRIPTION) do { \
            (void)ldr_register_app(APPID, DESCRIPTION); } while (false)


    #define LDR_LOG_UNREGISTER_DLT_APP() do { \
        (void)ldr_unregister_app(); } \
        while (false)

    #define LDR_LOG_INIT_DLT_CONTEXT(CONTEXT, CONTEXTID, DESCRIPTION) do { \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, LL_INFO, 0, NULL); } \
        while (false)

    #define LDR_LOG_INIT_DLT_CONTEXT_LL(CONTEXT, CONTEXTID, DESCRIPTION, LOG_LEVEL) do { \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, \
                                            LOG_LEVEL, 0, NULL); } \
        while (false)

    #define LDR_LOG_DECLARE_DLT_CONTEXT(CONTEXT, CONTEXTID, DESCRIPTION) do { \
        LdrContext *CONTEXT = NULL;                                       \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, LL_INFO, 0, NULL); } \
        while (false)

    #define LDR_LOG_DECLARE_DLT_CONTEXT_LL(CONTEXT, CONTEXTID, DESCRIPTION, LOG_LEVEL) do { \
        LdrContext *CONTEXT = NULL;                                       \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, \
                                            LOG_LEVEL, 0, NULL); } \
        while (false)

    //***************************************************************************************************************************************************************** */

    /**
     * @brief Registers a LDR application.
     *
     * This macro registers a LDR application with the provided app_id and description.
     * It is a shortcut for calling ldr_register_app() function.
     *
     * @param APPID The application ID for LDR registration.
     * @param DESCRIPTION The description of the registered LDR application.
     */
    #define LDR_LOG_REGISTER_APP(APPID, DESCRIPTION) do { \
            (void)ldr_register_app(APPID, DESCRIPTION); } while (false)
    
    /**
     * @brief Unregisters the LDR application.
     *
     * This macro unregisters the currently registered LDR application.
     * It is a shortcut for calling ldr_register_log_level_changed_callback() function.
     */
    #define LDR_LOG_UNREGISTER_APP() do { \
        (void)ldr_unregister_app(); } \
        while (false)

    /**
     * @brief Defines a logging context variable.
     *
     * This macro defines a logging context variable of type LdrContext.
     * It initializes the variable to 0 (null).
     *
     * @param CONTEXT The name of the logging context variable.
     */
    #define LDR_LOG_DEFINE_CONTEXT(CONTEXT) \
        LdrContext *CONTEXT = NULL


    /**
     * @brief Declares a logging context variable without definition.
     *
     * This macro declares a logging context variable of type LdrContext.
     * without defining it. The variable must be defined elsewhere.
     *
     * @param CONTEXT The name of the logging context variable.
     */
    #define LDR_LOG_REFERENCE_CONTEXT(CONTEXT) \
        extern LdrContext *CONTEXT

    /**
     * @brief Initializes a LDR logging context.
     *
     * This macro initializes a LDR logging context with the provided context ID
     * and description. It assigns the initialized context to the specified variable.
     * It is a shortcut for calling ldr_register_context() function.
     *
     * @param CONTEXT The name of the logging context variable to be initialized.
     * @param CONTEXTID The ID of the logging context.
     * @param DESCRIPTION The description of the logging context.
     */
    #define LDR_LOG_INIT_CONTEXT(CONTEXT, CONTEXTID, DESCRIPTION) do { \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, LL_INFO, 0, NULL); } \
        while (false)

    /**
     * @brief Initializes a LDR logging context with a custom log level.
     *
     * This macro initializes a LDR logging context with the provided context ID,
     * description, and log level. It assigns the initialized context to the specified
     * variable. It is a shortcut for calling ldr_register_context() function.
     *
     * @param CONTEXT The name of the logging context variable to be initialized.
     * @param CONTEXTID The ID of the logging context.
     * @param DESCRIPTION The description of the logging context.
     * @param LOG_LEVEL The custom log level to be used for the logging context.
     */
    #define LDR_LOG_INIT_CONTEXT_LL(CONTEXT, CONTEXTID, DESCRIPTION, LOG_LEVEL) do { \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, \
                                            LOG_LEVEL, 0, NULL); } \
        while (false)
    
    /**
     * @brief Declares a LDR logging context.
     *
     * This macro defines and initializes a LDR logging context with the provided context ID
     * and description. It assigns the initialized context to the specified variable.
     * It is a shortcut for calling LDR_LOG_DEFINE_CONTEXT + LDR_LOG_INIT_CONTEXT.
     * In some cases this macro might be more suitable. For example, for declaration
     * and initialization of the logging context in the global area.
     *
     * @param CONTEXT The name of the logging context variable to be initialized.
     * @param CONTEXTID The ID of the logging context.
     * @param DESCRIPTION The description of the logging context.
     */
    #define LDR_LOG_DECLARE_CONTEXT(CONTEXT, CONTEXTID, DESCRIPTION) \
        LdrContext *CONTEXT = NULL;                                       \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, LL_INFO, 0, NULL) \


    /**
     * @brief Initializes a LDR logging context with a custom log level.
     *
     * This macro initializes a LDR logging context with the provided context ID,
     * description, and log level. It assigns the initialized context to the specified
     * variable. It is a shortcut for calling LDR_LOG_DEFINE_CONTEXT_LL + LDR_LOG_INIT_CONTEXT_LL.
     * In some cases this macro might be more suitable. For example, for declaration
     * and initialization of the logging context in the global area.
     *
     * @param CONTEXT The name of the logging context variable to be initialized.
     * @param CONTEXTID The ID of the logging context.
     * @param DESCRIPTION The description of the logging context.
     * @param LOG_LEVEL The custom log level to be used for the logging context.
     */
    #define LDR_LOG_DECLARE_CONTEXT_LL(CONTEXT, CONTEXTID, DESCRIPTION, LOG_LEVEL) do { \
        LdrContext *CONTEXT = NULL;                                       \
        (void)ldr_register_context(&(CONTEXT), CONTEXTID, DESCRIPTION, \
                                            LOG_LEVEL, 0, NULL); } \
        while (false)

    /**
     * @brief Frees a logging context.
     *
     * This macro frees the memory allocated for a logging context.
     * It is a shortcut for calling ldr_log_free_context() function.
     *
     * @param CONTEXT The logging context to be freed.
     */
    #define LDR_LOG_FREE_CONTEXT(CONTEXT) do { \
        (void)ldr_log_free_context(&(CONTEXT)); }  \
        while (false)
    
    /**
     * @brief Registers a LDR loglevel changed callback function.
     *
     * This macro registers a loglevel changed callback function.
     * It is a shortcut for calling ldr_register_log_level_changed_callback() function.
     *
     * @param CONTEXT The name of the logging context variable.
     * @param CALLBACK The pointer to user callback function.
     */
    #define LDR_REGISTER_LOG_LEVEL_CHANGED_CALLBACK(CONTEXT, CALLBACK) do { \
        (void)ldr_register_log_level_changed_callback(CONTEXT, CALLBACK); } while(false)
    
    /**
     * @brief Logs a fatal error message.
     *
     * This macro logs a fatal error message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_FATAL
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_FATAL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_FATAL) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_FATAL, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs an error message.
     *
     * This macro logs an error message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_ERROR
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_ERROR(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_ERROR) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_ERROR, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a warning message.
     *
     * This macro logs a warning message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_WARN
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_WARN(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_WARN) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_WARN, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs an informational message.
     *
     * This macro logs an informational message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_INFO
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_INFO(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_INFO) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_INFO, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a debug message.
     *
     * This macro logs a debug message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_DEBUG
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_DEBUG(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_DEBUG) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_DEBUG, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a verbose message.
     *
     * This macro logs a verbose message using the provided log context and
     * format string. It is a shortcut for calling ldr_log() with the LL_VERBOSE
     * log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_VERBOSE(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_VERBOSE) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll(CONTEXT, LL_VERBOSE, __VA_ARGS__); \
            } \
        } \
        while(false)

    
    /**
     * @brief Logs a fatal error message, including the file and line number.
     *
     * This macro logs a fatal error message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_FATAL log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_FATAL_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_FATAL) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_FATAL, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs an error message, including the file and line number.
     *
     * This macro logs an error message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_ERROR log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_ERROR_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_ERROR) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_ERROR, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a warning message, including the file and line number.
     *
     * This macro logs a warning message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_WARN log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_WARN_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_WARN) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_WARN, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs an informational message, including the file and line number.
     *
     * This macro logs an informational message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_INFO log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_INFO_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_INFO) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_INFO, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a debug message, including the file and line number.
     *
     * This macro logs a debug message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_DEBUG log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_DEBUG_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_DEBUG) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_DEBUG, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a verbose message, including the file and line number.
     *
     * This macro logs a verbose message using the provided log context, format
     * string, and the file and line number where the log message originated. It is
     * a shortcut for calling ldr_log_fl() with the LL_VERBOSE log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param FORMAT The format string for the log message.
     * @param ... Additional optional arguments depending on the format string.
     */
    #define LDR_LOG_VERBOSE_FL(CONTEXT, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LL_VERBOSE) == LDR_RET_TRUE) \
            { \
                (void)ldr_log_write_ll_fl(CONTEXT, LL_VERBOSE, __FILE__, __LINE__, __VA_ARGS__); \
            } \
        } \
        while(false)

    /**
     * @brief Logs a message with custom log level.
     *
     * This macro logs a message with custom log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param LOG_LEVEL The log level to use for this message.
     * @param FORMAT The format string for the log message.
     */
    #define LDR_LOG_VARIADIC(CONTEXT, LOG_LEVEL, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LOG_LEVEL) == LDR_RET_TRUE) \
                { \
                    (void)ldr_log_write_ll(CONTEXT, LOG_LEVEL, __VA_ARGS__); \
                } \
        } \
        while(false)

    /**
     * @brief Logs a message with custom log level.
     *
     * This macro logs a message with custom log level.
     *
     * @param CONTEXT A pointer to the LdrLogContext object.
     * @param LOG_LEVEL The log level to use for this message.
     * @param FILE The name of the source file where the log message originated.
     * @param LINE The line number in the source file where the log message originated.
     * @param FORMAT The format string for the log message.
     */
    #define LDR_LOG_VARIADIC_FL(CONTEXT, LOG_LEVEL, __FILE__, __LINE__, ...) do { \
            if (ldr_user_is_logLevel_enabled(CONTEXT, LOG_LEVEL) == LDR_RET_TRUE) \
                { \
                    (void)ldr_log_write_ll_fl(CONTEXT, LOG_LEVEL, __FILE__, __LINE__, __VA_ARGS__); \
                } \
        } \
        while(false)

    /**
     * @brief Logs a preformatted sequence message in the following format:
     * MT:SQ|CT:RT|SI:1256|CN:Client_1|SN:Service_1|MN:my_method|ARG:arg1 arg2 arg3
     *
     * This macro calls the ldr_log_sequence function with the specified parameters
     * and log level set to LL_INFO.
     *
     * @param CONTEXT The logging context.
     * @param COMMUNICATION_TYPE CT.
     * @param SEQUENCE_ID SI.
     * @param CLIENT_NAME CN.
     * @param SERVICE_NAME SN.
     * @param METHOD_NAME MN.
     * @param ARGUMENTS ARG.
     */
    #define LDR_LOG_SEQUENCE(CONTEXT, COMMUNICATION_TYPE, SEQUENCE_ID, CLIENT_NAME, SERVICE_NAME, METHOD_NAME, ARGUMENTS) do { \
        (void)ldr_log_write_sequence(CONTEXT, LL_INFO, COMMUNICATION_TYPE, SEQUENCE_ID, CLIENT_NAME, SERVICE_NAME, METHOD_NAME,  \
                            ARGUMENTS); } \
        while(false)

    /**
     * @brief Logs a preformatted sequence message with given log level in the following format:
     * MT:SQ|CT:RT|SI:1256|CN:Client_1|SN:Service_1|MN:my_method|ARG:arg1 arg2 arg3
     *
     * This macro calls the ldr_log_sequence function with the specified parameters
     * and the given log level.
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     * @param COMMUNICATION_TYPE CT.
     * @param SEQUENCE_ID SI.
     * @param CLIENT_NAME CN.
     * @param SERVICE_NAME SN.
     * @param METHOD_NAME MN.
     * @param ARGUMENTS ARG.
     */
    #define LDR_LOG_SEQUENCE_LL(CONTEXT, LOG_LEVEL, COMMUNICATION_TYPE, SEQUENCE_ID, CLIENT_NAME, SERVICE_NAME, METHOD_NAME, ARGUMENTS) do { \
        (void)ldr_log_write_sequence(CONTEXT, LOG_LEVEL, COMMUNICATION_TYPE, SEQUENCE_ID, CLIENT_NAME, SERVICE_NAME, METHOD_NAME,  \
                            ARGUMENTS); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a string value.
     *
     * This macro calls the ldr_log_kpi function with the specified parameters
     * and log level set to LL_INFO.
     *
     * @param CONTEXT The logging context.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The string value of the KPI (KV).
     */
    #define LDR_LOG_KPI(CONTEXT, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi(CONTEXT, LL_INFO, KPI_NAME, KPI_VALUE); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a numeric value.
     *
     * This macro calls the ldr_log_kpi_n function with the specified parameters
     * and log level set to LL_INFO.
     *
     * @param CONTEXT The logging context.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The numeric value of the KPI (KV).
     */
    #define LDR_LOG_KPI_N(CONTEXT, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi_n(CONTEXT, LL_INFO, KPI_NAME, KPI_VALUE); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a floating-point value.
     *
     * This macro calls the ldr_log_kpi_f function with the specified parameters
     * and log level set to LL_INFO.
     *
     * @param CONTEXT The logging context.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The floating-point value of the KPI (KV).
     */
    #define LDR_LOG_KPI_F(CONTEXT, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi_f(CONTEXT, LL_INFO, KPI_NAME, KPI_VALUE); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a string value and a specific log level.
     *
     * This macro calls the ldr_log_kpi function with the specified parameters
     * and the given log level.
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The string value of the KPI (KV).
     */
    #define LDR_LOG_KPI_LL(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a numeric value and a specific log level.
     *
     * This macro calls the ldr_log_kpi_n function with the specified parameters
     * and the given log level.
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The numeric value of the KPI (KV).
     */
    #define LDR_LOG_KPI_LL_N(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi_n(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE); } \
        while(false)

    /**
     * @brief Logs a Key Performance Indicator (KPI) with a floating-point value and a specific log level.
     *
     * This macro calls the ldr_log_kpi_f function with the specified parameters
     * and the given log level.
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     * @param KPI_NAME The name of the KPI (KN).
     * @param KPI_VALUE The floating-point value of the KPI (KV).
     */
    #define LDR_LOG_KPI_LL_F(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE) do { \
        (void)ldr_log_write_kpi_f(CONTEXT, LOG_LEVEL, KPI_NAME, KPI_VALUE); } \
        while(false)
    
    /**
     * @brief Logs an Event with log level set
     *
     * This macro calls the ldr_log_event function with the specified parameters
     * and log level set to LL_INFO. Message format is:
     * MT:EV|EN:MY_EVENT|ET:START|EID:25|EM:Frame number - 1232
     *
     * @param CONTEXT The logging context.
     * @param EVENT_NAME EN.
     * @param EVENT_TYPE ET. Enumeration EventType: ET_START or ET_END.
     * @param EVENT_ID EID.
     * @param METADATA EM. Arbitrary string
     */
    #define LDR_LOG_EVENT(CONTEXT, EVENT_NAME, EVENT_TYPE, EVENT_ID, METADATA) do { \
        (void)ldr_log_write_event(CONTEXT, LL_INFO, EVENT_NAME, EVENT_TYPE, EVENT_ID, METADATA); } \
        while(false)

    /**
     * @brief Logs an Event with log level set
     *
     * This macro calls the ldr_log_event function with the specified parameters
     * and the given log level. Message format is:
     * MT:EV|EN:MY_EVENT|ET:START|EID:25|EM:Frame number - 1232
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     * @param EVENT_NAME EN.
     * @param EVENT_TYPE ET. Enumeration EventType: ET_START or ET_END.
     * @param EVENT_ID EID.
     * @param METADATA EM. Arbitrary string
     */
    #define LDR_LOG_EVENT_LL(CONTEXT, LOG_LEVEL, EVENT_NAME, EVENT_TYPE, EVENT_ID, METADATA) do { \
        (void)ldr_log_write_event(CONTEXT, LOG_LEVEL, EVENT_NAME, EVENT_TYPE, EVENT_ID, METADATA); } \
        while(false)

    /**
     * @brief This macro set configs regarding LDR function.
     *
     *
     * Example of the usage:
     *
     * LdrLogConfig config;
     * config.enable_tid_logging = true;
     * LDR_LOG_SET_CONFIG(config);
     *
     *
     * @param LDR_LOG_CONFIG The ldr_log configs.
     */
    #define LDR_LOG_SET_CONFIG(LDR_LOG_CONFIG) \
        ldr_log_set_config(LDR_LOG_CONFIG)

    /**
     * @brief This macro get configs regarding LDR function.
     *
     *
     * Example of the usage:
     *
     * LdrLogConfig ldr_log_config_ptr = ldr_log_get_config();
     *
     *
     * @return ldr_log_config The ldr_log configs.
     */
    #define LDR_LOG_GET_CONFIG() \
        ldr_log_get_config()

    /**
     * @brief This macro together with the LDR_FI creates a possibility to
     * declare the block of code that will be:
     *
     * - Entered only if the provided log_level is turned on for the passed
     * context
     * - Compiled only if LDR_LOGGING_DISABLED is not defined
     *
     * This allows for the control of the consumption of the resources that
     * are spent on the logging system in a more precise manner.
     *
     * Example of the usage:
     *
     * LDR_IF_LOG_LEVEL_ENABLED(my_ctx, LL_INFO)
     * std::string my_logging_string;
     * my_logging_string.append("Hello");
     * my_logging_string.append(", world!");
     * // Do you need anything else to prepare your log message
     * LDR_LOG_INFO(my_ctx, my_logging_string);
     * LDR_FI()
     *
     * If the target log level is turned off for the passed context, you
     * will spare not only resources for the LDR_LOG_INFO call but also the
     * resources for the compilation of the log message string.
     *
     * In case of high frequent logging, it is crucial to use this
     * functionality!!!
     *
     * @param CONTEXT The logging context.
     * @param LOG_LEVEL The log level to use.
     */
    #define LDR_IF_LOG_LEVEL_ENABLED(CONTEXT, LOG_LEVEL)                                                                   \
        if (ldr_user_is_logLevel_enabled(CONTEXT, LOG_LEVEL) == LDR_RET_TRUE)                                                          \
        {

    /**
     * @brief This macro should close the block of code that was opened
     * with the LDR_IF_LOG_LEVEL_ENABLED macro call.
     */
    #define LDR_FI() }


    /**
     * @brief This macro logs function entry with specified context and log level.
     *
     * Automatically captures the current function name and timestamps the entry.
     * Uses internal timing mechanism for performance tracking.
     *
     * Example of the usage:
     *
     * LDR_LOG_FUNCTION_ENTRY_LL(my_context, LOG_LEVEL_DEBUG);
     *
     * @param CONTEXT The logging context identifier
     * @param LOG_LEVEL The severity level for this log entry
     */
    #define LDR_LOG_FUNCTION_ENTRY_LL(CONTEXT, LOG_LEVEL)                                            \
            do                                                                                                                 \
            {                                                                                                                  \
                ldr_log_write_f_entry_internal_time(CONTEXT, LOG_LEVEL, __func__);                       \
            } while (0)

    /**
     * @brief This macro logs function exit with specified context and log level.
     *
     * Automatically captures the current function name and timestamps the exit.
     * Uses internal timing mechanism for performance tracking.
     *
     * Example of the usage:
     *
     * LDR_LOG_FUNCTION_EXIT_LL(my_context, LOG_LEVEL_DEBUG);
     *
     * @param CONTEXT The logging context identifier
     * @param LOG_LEVEL The severity level for this log entry
     */
    #define LDR_LOG_FUNCTION_EXIT_LL(CONTEXT, LOG_LEVEL)                                             \
            do                                                                                                                 \
            {                                                                                                                  \
                ldr_log_write_f_exit_internal_time(CONTEXT, LOG_LEVEL, __func__);                        \
            } while (0)

    /**
     * @brief This macro logs function exit with return value, context and log level.
     *
     * Automatically captures the current function name, return value and timestamps the exit.
     * Uses internal timing mechanism for performance tracking.
     *
     * Example of the usage:
     *
     * LDR_LOG_FUNCTION_EXIT_WITH_RETURN_CODE_LL(my_context, LOG_LEVEL_DEBUG, return_code);
     *
     * @param CONTEXT The logging context identifier
     * @param LOG_LEVEL The severity level for this log entry
     * @param RETURN_VAL The return value to be logged
     */
    #define LDR_LOG_FUNCTION_EXIT_WITH_RETURN_CODE_LL(CONTEXT, LOG_LEVEL, RETURN_VAL)               \
            do                                                                                                                 \
            {                                                                                                                  \
                ldr_log_write_f_exit_internal_time_with_return(CONTEXT, LOG_LEVEL, RETURN_VAL, __func__);                        \
            } while (0)

    /**
     * @brief This macro registers a predefined logging context with specific log level.
     *
     * Allows setting up logging contexts with override log levels for 
     * selective logging control across different modules or components.
     *
     * Example of the usage:
     *
     * LDR_LOG_PREDEFINE_CONTEXT(MODULE_NETWORK, LOG_LEVEL_INFO);
     *
     * @param CONTEXTID The context identifier to register
     * @param LOG_LEVEL The log level to associate with this context
     */
    #define LDR_LOG_PREDEFINE_CONTEXT(CONTEXTID, LOG_LEVEL) \
            (void)ldr_register_override_context(CONTEXTID, LOG_LEVEL)

    /**
     * @brief This macro retrieves the current log level for a specific logging context.
     *
     * Returns the log level associated with the given context identifier,
     * allowing runtime queries of context-specific logging configurations.
     *
     * @param CONTEXTID The context identifier to query
     * @return The log level associated with the specified context
     */
    #define LDR_LOG_GET_CONTEXT_LOG_LEVEL(CONTEXTID) \
            ldr_log_get_context_ll(CONTEXTID)

    /**
     * @brief Registers a software component injection callback function.
     *
     * This macro registers a callback function for software component injection
     * using the provided context and identifier. It serves as a wrapper around
     * the ldr_user_register_swc_injection() function, casting the return value
     * to void to indicate that the return status is intentionally ignored.
     *
     * @param CONTEXT A pointer to the context object used for registration.
     * @param ID The unique identifier for the software component injection point.
     * @param CALLBACK_FUNC The callback function to be registered for injection.
     */
    #define LDR_LOG_REGISTER_SWC_INJECTION(CONTEXT, ID, CALLBACK_FUNC) \
                (void)ldr_user_register_swc_injection(CONTEXT, ID, CALLBACK_FUNC)

    /**
     * @brief Dumps a raw memory region to the log.
     *
     * This macro starts a log write operation for the given context and log level.
     * If the log write is successfully started, it writes the specified memory range
     * as raw bytes and then finishes the log write operation. If starting the log
     * write fails, the return value is not propagated; an error is printed instead.
     *
     * @param CONTEXT   A pointer to the logging context used for the write operation.
     * @param LOGLEVEL  The log level used for the dump output.
     * @param MEM_ADDR  Pointer to the start address of the memory region to dump.
     * @param MEM_SIZE  Size in bytes of the memory region to dump.
     */
    #define LDR_LOG_DUMP_MEM(CONTEXT, LOGLEVEL, MEM_ADDR, MEM_SIZE) \
        ldr_log_dump_mem(CONTEXT, LOGLEVEL, MEM_ADDR, MEM_SIZE);
    
    /*************************************************************************************** */
    // The APIs below are not providing to customer.

    #define LDR_LOG(CONTEXT, LOGLEVEL, ...) \
        do { \
            LdrContextData log_local; \
            LdrReturnValue ret = ldr_user_log_write_start(CONTEXT, &log_local, LOGLEVEL); \
            if (ret == LDR_RET_TRUE) \
            { \
                __VA_ARGS__; \
                (void)ldr_user_log_write_finish(&log_local); \
            } else { printf("Error: %d\n", (int)ret);} \
        } while (false)


    #define LDR_LOG_BOOL(X) \
        (void)ldr_user_log_bool(&log_local, X)

    #define LDR_LOG_INT8(X) \
        (void)ldr_user_log_int8(&log_local, X)

    #define LDR_LOG_INT16(X) \
        (void)ldr_user_log_int16(&log_local, X)

    #define LDR_LOG_INT32(X) \
        (void)ldr_user_log_int32(&log_local, X)

    #define LDR_LOG_INT64(X) \
        (void)ldr_user_log_int64(&log_local, X)

    #define LDR_LOG_STR(STR) \
        (void)ldr_user_log_string(&log_local, STR)

    /*************************************************************************************** */

    #endif // LDR_LOGGING_DISABLED

#ifdef __cplusplus
}
#endif

#endif // RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_MACROS_H