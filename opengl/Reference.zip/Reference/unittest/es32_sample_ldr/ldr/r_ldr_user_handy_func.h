#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_HANDY_FUNC_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_HANDY_FUNC_H

#include "r_ldr_types.h"
#include "r_ldr_user.h"
#include "r_ldr_timer.h"

#ifdef __cplusplus
extern "C" {
#endif


typedef enum TimeStampType
{
    LDR_OS_TIMESTAMP = 0,
    LDR_ARM_GENERIC_TIMESTAMP
} TimeStampType;

typedef struct
{
    bool enable_tid_logging;
    bool enable_tee_logging;
    TimeStampType timestamp_type;
} LdrLogConfig;

typedef enum CommunicationType
{
    CT_REQUEST,
    CT_RESPONSE,
    CT_EVENT,
    CT_NUM
} CommunicationType;

typedef enum EventType
{
    ET_START,
    ET_END
} EventType;

LdrLogConfig *ldr_log_get_config();
void ldr_log_set_config(LdrLogConfig ldr_log_config);

LdrReturnValue ldr_log_write_ll(LdrContext *context, LdrLogLevelType log_level, const char * format, ...);
LdrReturnValue ldr_log_write_ll_fl(LdrContext *context, LdrLogLevelType log_level, const char *file, const int line, const char * format, ...);
LdrReturnValue ldr_log_write_sequence(LdrContext *context, LdrLogLevelType log_level, 
                                      CommunicationType communication_type, int sequence_id, const char * client_name,
                                      const char * service_name, const char * method_name, const char * arguments);
LdrReturnValue ldr_log_write_kpi(LdrContext *context, LdrLogLevelType log_level,
                                const char *name, const char *value
                                );
LdrReturnValue ldr_log_write_kpi_n(LdrContext *context, LdrLogLevelType log_level,
                                const char *name, long value
                                );
LdrReturnValue ldr_log_write_kpi_f(LdrContext *context, LdrLogLevelType log_level,
                                const char *name, double value
                                );
LdrReturnValue ldr_log_write_event(LdrContext *context, LdrLogLevelType log_level, 
                                    const char * event_name, EventType event_type, int event_id, const char * metadata);
LdrReturnValue ldr_log_write_f_entry_internal_time(LdrContext *context, 
                                                    LdrLogLevelType log_level, 
                                                    const char *func_name);
LdrReturnValue ldr_log_write_f_exit_internal_time(LdrContext *context, 
                                                    LdrLogLevelType log_level, 
                                                    const char *func_name);
LdrReturnValue ldr_log_write_f_exit_internal_time_with_return(LdrContext *context, 
                                                                LdrLogLevelType log_level, 
                                                                const int32_t return_val, 
                                                                const char *func_name);
LdrReturnValue ldr_log_dump_mem(LdrContext *context, 
                                LdrLogLevelType log_level, 
                                const void *raw_addr, 
                                const uint16_t raw_size);

#ifdef __cplusplus
}
#endif

#endif