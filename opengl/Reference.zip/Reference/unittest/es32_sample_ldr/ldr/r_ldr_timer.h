#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LOG_DATA_RECORDER_INCLUDE_RCAR_XOS_LDR_TIMER_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LOG_DATA_RECORDER_INCLUDE_RCAR_XOS_LDR_TIMER_H



#include <stdio.h>
#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif

    struct ldr_timer{
        uint64_t nsec;
    };

#ifdef __cplusplus
}
#endif

#endif