#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_USER_H

#include <stdbool.h>
#include <stdio.h>

#include "r_ldr_types.h"
#include "r_ldr_common.h"
#include "r_ldr_user_cfg.h"

#ifndef LDR_CR52
    #include <pthread.h>
#endif

#ifdef __cplusplus
extern "C" {
#endif

#define LDR_POSIX_SHM_BASE_FILE_NAME 50

typedef enum
{
    LDR_LINUX_QNX_MODE = 0,
    LDR_FREERTOS_MODE = 1
} LDR_LOG_API_MODE;

typedef enum
{
    LDR_NOT_OVERRIDE = 0,
    LDR_USER_OVERRIDE = 1,
} LDR_OVERRIDE_STATE;


typedef struct
{
    bool in_use;
    uint8_t mcnt;
    void *miso_mem_io;

    uint8_t contextID[LDR_ID_SIZE];
    int8_t user_override;
    int32_t log_level_pos;
    int8_t log_level;
    int8_t trace_status;
    int32_t pid;
    uint8_t context_description[UINT8_MAX];
    uint16_t shm_counter_reg;
    
    /* LDR Log Level changed callback */
    void (*log_level_changed_callback)(uint8_t context_id[LDR_ID_SIZE], uint8_t log_level, uint8_t trace_status);
} LdrContext;


typedef struct
{
    LdrContext *handle;
    unsigned char buffer[LDR_USER_BUF_MAX_SIZE];
    uint32_t size;
    uint32_t size_limit;

    int8_t log_level;
    int8_t trace_status; 

    int32_t args_num;
    LdrTimestampType use_timestamp;
    uint32_t user_timestamp;
} LdrContextData;


typedef struct
{
    char appId[LDR_ID_SIZE];
    char ctxId[LDR_ID_SIZE];
    int8_t ll;
} ldr_env_ll_item;


typedef struct
{
    ldr_env_ll_item *item;
    size_t array_size;
    size_t num_elem;
} ldr_env_ll_set;

typedef struct
{
    ldr_env_ll_set initial_ll_set;

    uint8_t verbose_mode;
    int8_t use_extended_header_for_non_verbose;
    uint8_t with_session_id;
    uint8_t with_timestamp;
    uint8_t with_ecu_id;

    int8_t enable_local_print;
    uint16_t log_buf_len;
} ldr_lib_configs;



typedef struct
{
    void     *mutex_id;
    void *context_rwlock;

    bool initialized;
    bool in_use;
    LDR_LOG_API_MODE mode;
    bool atexit_registered;
    bool housekeeper_running;
    bool serial_transmitter;
    
    char ecuID[LDR_ID_SIZE];
    char appID[LDR_ID_SIZE];
    char application_description[UINT8_MAX];

    LdrContext context_list[LDR_USER_CONTEXT_ALLOC_SIZE];
    uint16_t context_list_num;
    uint16_t context_file_counter;

    int8_t overflow;
    uint32_t overflow_counter;

    void *mosi_mem_io;
    void *miso_mem_io;
#ifdef LDR_LINUX_QNX
    char base_file_name[LDR_POSIX_SHM_BASE_FILE_NAME];
#endif
} LdrUser;


typedef LdrContext * LdrLogContextPtr;


LdrReturnValue  ldr_register_app(const char *apid, const char *description);
LdrReturnValue ldr_log_free_context(LdrContext **handle);
LdrReturnValue ldr_unregister_app(void);
LdrReturnValue  ldr_user_log_write_finish(LdrContextData *log);
LdrReturnValue ldr_register_override_context(const char *context_id, 
                                            int8_t log_level);
LdrReturnValue ldr_register_context(LdrContext **handle,
                                                const char *contextid,
                                                const char *description,
                                                int loglevel,
                                                int tracestatus,
                                                void (*log_level_changed_callback)(uint8_t context_id[LDR_ID_SIZE],
                                                                                       uint8_t log_level,
                                                                                       uint8_t trace_status));

LdrReturnValue ldr_user_log_write_start(
                                           LdrContext *handle,
                                           LdrContextData *log,
                                           LdrLogLevelType loglevel);

LdrReturnValue  ldr_log_string(LdrContext *handle, LdrLogLevelType loglevel, const char *text);
void ldr_register_log_level_changed_callback(LdrContext *handle,
                                                       void (*ldr_log_level_changed_callback)(
                                                           uint8_t context_id[LDR_ID_SIZE],
                                                           uint8_t log_level,
                                                           uint8_t trace_status));

LdrReturnValue ldr_user_log_int8(LdrContextData *log, int8_t value);
LdrReturnValue ldr_user_log_int16(LdrContextData *log, int16_t value);
LdrReturnValue ldr_user_log_int32(LdrContextData *log, int32_t value);
LdrReturnValue ldr_user_log_int64(LdrContextData *log, int64_t value);
LdrReturnValue ldr_user_log_bool(LdrContextData *log, bool value);
LdrReturnValue ldr_user_log_string(LdrContextData *log, char *string);

int8_t ldr_log_get_context_ll(LdrContext *handle);

static inline LdrReturnValue ldr_user_is_logLevel_enabled(LdrContext *handle, LdrLogLevelType loglevel)
{
    LdrReturnValue result = LDR_RET_LOGGING_DISABLED;

    if ((loglevel < LL_DEFAULT) || (loglevel >= LL_MAX)) {
        result = LDR_RET_WRONG_PARAMETER;
    } else if (handle == NULL) {
        result = LDR_RET_WRONG_PARAMETER;
    } else if ((loglevel <= handle->log_level) && (loglevel != LL_OFF)) {
        result = LDR_RET_TRUE;
    }

    return result;
}


#ifdef __cplusplus
}
#endif

#endif