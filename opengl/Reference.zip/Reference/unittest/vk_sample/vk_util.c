/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_util.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2017.10.16
//            - Modify memoryTypeIndex of MemoryAllocateInfo.
//          : 2017.10.31
//            - Add a check on the supported surface.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include <stdbool.h>
#include <math.h>
#include <assert.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  DEFINES
 ****************************************************************************/
#define	_STRINGIFY(x) # x
#define	STRINGIFY(x) _STRINGIFY(x)
#define VK_GET_DEVICE_PROC(dev, name)                                        \
{                                                                            \
	fn_##name = (PFN_##name )vkGetDeviceProcAddr(dev, STRINGIFY(name));      \
	if (fn_##name == NULL) {                                                 \
		printf("error: vkGetDeviceProcAddr failed(%s).\n", STRINGIFY(name)); \
		return 0;                                                            \
	}                                                                        \
}
#define VK_GET_INSTANCE_PROC(ins, name)                                        \
{                                                                              \
	fn_##name = (PFN_##name )vkGetInstanceProcAddr(ins, STRINGIFY(name));      \
	if (fn_##name == NULL) {                                                   \
		printf("error: vkGetInstanceProcAddr failed(%s).\n", STRINGIFY(name)); \
		return 0;                                                              \
	}                                                                          \
}

PFN_vkAcquireNextImageKHR                        fn_vkAcquireNextImageKHR = NULL;
PFN_vkCreateDisplayPlaneSurfaceKHR               fn_vkCreateDisplayPlaneSurfaceKHR = NULL;
PFN_vkCreateSwapchainKHR                         fn_vkCreateSwapchainKHR = NULL;
PFN_vkDestroySurfaceKHR                          fn_vkDestroySurfaceKHR = NULL;
PFN_vkDestroySwapchainKHR                        fn_vkDestroySwapchainKHR = NULL;
PFN_vkGetDisplayModePropertiesKHR                fn_vkGetDisplayModePropertiesKHR = NULL;
PFN_vkGetDisplayPlaneSupportedDisplaysKHR        fn_vkGetDisplayPlaneSupportedDisplaysKHR = NULL;
PFN_vkGetPhysicalDeviceDisplayPlanePropertiesKHR fn_vkGetPhysicalDeviceDisplayPlanePropertiesKHR = NULL;
PFN_vkGetPhysicalDeviceDisplayPropertiesKHR      fn_vkGetPhysicalDeviceDisplayPropertiesKHR = NULL;
PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR    fn_vkGetPhysicalDeviceSurfaceCapabilitiesKHR = NULL;
PFN_vkGetPhysicalDeviceSurfaceFormatsKHR         fn_vkGetPhysicalDeviceSurfaceFormatsKHR = NULL;
PFN_vkGetPhysicalDeviceSurfacePresentModesKHR    fn_vkGetPhysicalDeviceSurfacePresentModesKHR = NULL;
PFN_vkGetSwapchainImagesKHR                      fn_vkGetSwapchainImagesKHR = NULL;
PFN_vkQueuePresentKHR                            fn_vkQueuePresentKHR = NULL;

/*****************************************************************************
 * Function Name  : Normalize
 * Description    : 
 *****************************************************************************/
static float Normalize(float afVout[3], float afVin[3])
{
	float fLen;

	fLen = afVin[0] * afVin[0] + afVin[1] * afVin[1] + afVin[2] * afVin[2];

	if (fLen <= 0.0f) {
		afVout[0] = 0.0f;
		afVout[1] = 0.0f;
		afVout[2] = 0.0f;
		return fLen;
	}

	if (fLen == 1.0f) {
		afVout[0] = afVin[0];
		afVout[1] = afVin[1];
		afVout[2] = afVin[2];
		return fLen;
	} else {
		fLen = 1.0f / (float)sqrt((double)fLen);

		afVout[0] = afVin[0] * fLen;
		afVout[1] = afVin[1] * fLen;
		afVout[2] = afVin[2] * fLen;
		return fLen;
	}
}

/*****************************************************************************
 * Function Name  : LoadIdentity
 * Description    : 
 *****************************************************************************/
void LoadIdentity(float pMatrix[4][4])
{
	pMatrix[0][0] = 1.0f;
	pMatrix[0][1] = 0.0f;
	pMatrix[0][2] = 0.0f;
	pMatrix[0][3] = 0.0f;

	pMatrix[1][0] = 0.0f;
	pMatrix[1][1] = 1.0f;
	pMatrix[1][2] = 0.0f;
	pMatrix[1][3] = 0.0f;

	pMatrix[2][0] = 0.0f;
	pMatrix[2][1] = 0.0f;
	pMatrix[2][2] = 1.0f;
	pMatrix[2][3] = 0.0f;

	pMatrix[3][0] = 0.0f;
	pMatrix[3][1] = 0.0f;
	pMatrix[3][2] = 0.0f;
	pMatrix[3][3] = 1.0f;
}

/*****************************************************************************
 * Function Name  : MultMatrix
 * Description    : 
 *****************************************************************************/
void MultMatrix(float psRes[4][4], float psSrcA[4][4], float psSrcB[4][4])
{
	float fB00, fB01, fB02, fB03;
	float fB10, fB11, fB12, fB13;
	float fB20, fB21, fB22, fB23;
	float fB30, fB31, fB32, fB33;
	int i;

	fB00 = psSrcB[0][0]; fB01 = psSrcB[0][1];
	fB02 = psSrcB[0][2]; fB03 = psSrcB[0][3];
	fB10 = psSrcB[1][0]; fB11 = psSrcB[1][1];
	fB12 = psSrcB[1][2]; fB13 = psSrcB[1][3];
	fB20 = psSrcB[2][0]; fB21 = psSrcB[2][1];
	fB22 = psSrcB[2][2]; fB23 = psSrcB[2][3];
	fB30 = psSrcB[3][0]; fB31 = psSrcB[3][1];
	fB32 = psSrcB[3][2]; fB33 = psSrcB[3][3];

	for (i = 0; i < 4; i++) {
		psRes[i][0] = psSrcA[i][0] * fB00 + psSrcA[i][1] * fB10 + psSrcA[i][2] * fB20 + psSrcA[i][3] * fB30;
		psRes[i][1] = psSrcA[i][0] * fB01 + psSrcA[i][1] * fB11 + psSrcA[i][2] * fB21 + psSrcA[i][3] * fB31;
		psRes[i][2] = psSrcA[i][0] * fB02 + psSrcA[i][1] * fB12 + psSrcA[i][2] * fB22 + psSrcA[i][3] * fB32;
		psRes[i][3] = psSrcA[i][0] * fB03 + psSrcA[i][1] * fB13 + psSrcA[i][2] * fB23 + psSrcA[i][3] * fB33;
	}
}

/*****************************************************************************
 * Function Name  : Persp
 * Description    : 
 *****************************************************************************/
void Persp(float pMatrix[4][4], float fovy, float aspect, float zNear, float zFar)
{
	float sine, cotangent, deltaZ, radians, m[4][4];

	LoadIdentity(m);
	radians = fovy / 2.0f * M_PI / 180.0f;

	deltaZ = zFar - zNear;
	sine = (float)sin(radians);
	if ((deltaZ == 0.0f) || (sine == 0.0f) || (aspect == 0.0f)) {
		return;
	}

	cotangent = (float)cos(radians) / sine;

	m[0][0] = cotangent / aspect;
	m[1][1] = cotangent;
	m[2][2] = -(zFar + zNear)/ deltaZ;
	m[2][3] = -1.0f;
	m[3][2] = -1.0f * zNear * zFar / deltaZ;
	m[3][3] = 0.0f;

	MultMatrix(pMatrix, m, pMatrix);
}

/*****************************************************************************
 * Function Name  : Translate
 * Description    : 
 *****************************************************************************/
void Translate(float pMatrix[4][4], float fX, float fY, float fZ)
{
	float fM30, fM31, fM32, fM33;

	fM30 = fX * pMatrix[0][0] + fY * pMatrix[1][0] + fZ * pMatrix[2][0] + pMatrix[3][0];
	fM31 = fX * pMatrix[0][1] + fY * pMatrix[1][1] + fZ * pMatrix[2][1] + pMatrix[3][1];
	fM32 = fX * pMatrix[0][2] + fY * pMatrix[1][2] + fZ * pMatrix[2][2] + pMatrix[3][2];
	fM33 = fX * pMatrix[0][3] + fY * pMatrix[1][3] + fZ * pMatrix[2][3] + pMatrix[3][3];

	pMatrix[3][0] = fM30;
	pMatrix[3][1] = fM31;
	pMatrix[3][2] = fM32;
	pMatrix[3][3] = fM33;
}

/*****************************************************************************
 * Function Name  : Rotate
 * Description    : 
 *****************************************************************************/
void Rotate(float pMatrix[4][4], float fX, float fY, float fZ, float fAngle)
{
	float fRadians, fSine, fCosine, fAB, fBC, fCA, fT;
	float afAv[4], afAxis[4];
	float afMatrix[4][4];
	float degreesToRadians = M_PI / 180.0f;

	afAv[0] = fX;
	afAv[1] = fY;
	afAv[2] = fZ;
	afAv[3] = 0;

	Normalize(afAxis, afAv);

	fRadians = fAngle * degreesToRadians;
	fSine = (float)sin(fRadians);
	fCosine = (float)cos(fRadians);

	fAB = afAxis[0] * afAxis[1] * (1 - fCosine);
	fBC = afAxis[1] * afAxis[2] * (1 - fCosine);
	fCA = afAxis[2] * afAxis[0] * (1 - fCosine);

	LoadIdentity(afMatrix);

	fT = afAxis[0] * afAxis[0];
	afMatrix[0][0] = fT + fCosine * (1 - fT);
	afMatrix[2][1] = fBC - afAxis[0] * fSine;
	afMatrix[1][2] = fBC + afAxis[0] * fSine;

	fT = afAxis[1] * afAxis[1];
	afMatrix[1][1] = fT + fCosine * (1 - fT);
	afMatrix[2][0] = fCA + afAxis[1] * fSine;
	afMatrix[0][2] = fCA - afAxis[1] * fSine;

	fT = afAxis[2] * afAxis[2];
	afMatrix[2][2] = fT + fCosine * (1 - fT);
	afMatrix[1][0] = fAB - afAxis[2] * fSine;
	afMatrix[0][1] = fAB + afAxis[2] * fSine;

	MultMatrix(pMatrix, afMatrix, pMatrix);
}

/*****************************************************************************
 * Function Name  : BindExtensionsAPI
 * Description    : 
 *****************************************************************************/
VkBool32 BindExtensionsAPI(void)
{
	assert((g_Instance != NULL) && (g_Device != NULL));

	VK_GET_INSTANCE_PROC(g_Instance, vkCreateDisplayPlaneSurfaceKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkDestroySurfaceKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetDisplayModePropertiesKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetDisplayPlaneSupportedDisplaysKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetPhysicalDeviceDisplayPlanePropertiesKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetPhysicalDeviceDisplayPropertiesKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetPhysicalDeviceSurfaceCapabilitiesKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetPhysicalDeviceSurfaceFormatsKHR);
	VK_GET_INSTANCE_PROC(g_Instance, vkGetPhysicalDeviceSurfacePresentModesKHR);
	VK_GET_DEVICE_PROC(g_Device, vkAcquireNextImageKHR);
	VK_GET_DEVICE_PROC(g_Device, vkCreateSwapchainKHR);
	VK_GET_DEVICE_PROC(g_Device, vkDestroySwapchainKHR);
	VK_GET_DEVICE_PROC(g_Device, vkGetSwapchainImagesKHR);
	VK_GET_DEVICE_PROC(g_Device, vkQueuePresentKHR);

	return VK_TRUE;
}

/*****************************************************************************
 * Function Name  : readBinaryFile
 * Description    : 
 *****************************************************************************/
static char *readBinaryFile(const char *fileName, size_t *psize)
{
	long int size;
	void *shaderCode;

	FILE *fp = fopen(fileName, "rb");
	if (!fp) {
		return NULL;
	}

	fseek(fp, 0L, SEEK_END);
	size = ftell(fp);

	fseek(fp, 0L, SEEK_SET);

	shaderCode = malloc(size);
	assert(shaderCode != NULL);

	if (fread(shaderCode, size, 1, fp) != 1) {
		return NULL;
	}

	*psize = size;

	return (char*)shaderCode;
}

/*****************************************************************************
 * Function Name  : LoadShader
 * Description    : 
 *****************************************************************************/
VkShaderModule LoadShader(const char *fileName)
{ 
	size_t size = 0;
	char *shaderCode = readBinaryFile(fileName, &size);

	VkShaderModule shaderModule = VK_NULL_HANDLE;
	VkShaderModuleCreateInfo moduleCreateInfo = {
		.sType    = VK_STRUCTURE_TYPE_SHADER_MODULE_CREATE_INFO,
		.pNext    = NULL,
		.flags    = 0,
		.codeSize = size,
		.pCode    = (uint32_t*)shaderCode};
	VkResult ret; 

	if (size <= 0) {
		printf("error: cannot get shader code (%s).\n", fileName);
		if (shaderCode != NULL) {
			free(shaderCode);
		}
		return VK_NULL_HANDLE;
	}

	ret = vkCreateShaderModule(g_Device,
							   &moduleCreateInfo, NULL, &shaderModule);
	if (ret != VK_SUCCESS) {
		printf("error: vkCreateShaderModule failed.\n");
		if (shaderCode != NULL) {
			free(shaderCode);
		}
		return VK_NULL_HANDLE;
	}

	if (shaderCode != NULL) {
		free(shaderCode);
	}

	return shaderModule;
}

/*****************************************************************************
 * Function Name  : GetMemoryTypeIndex
 * Description    : 
 *****************************************************************************/
uint32_t GetMemoryTypeIndex(VkFlags reqMask, uint32_t typeBits)
{
	uint32_t typeIndex = 0;
	uint32_t i;

	for (i = 0; i < 32; i++) {
		if ((typeBits & 0x00000001) == 0x00000001) {
			if ((g_PhysMemoryProps.memoryTypes[i].propertyFlags & reqMask) == reqMask) {
				typeIndex = i;
				break;
			}
		}
		typeBits >>= 1;
	}

	return typeIndex;
}

/*****************************************************************************
 * Function Name  : calcFPS
 * Description    : 
 *****************************************************************************/
#include <time.h>
#include <sys/time.h>
#ifndef TIMESPEC_TO_TIMEVAL
#define TIMESPEC_TO_TIMEVAL(tv, ts) { \
		(tv)->tv_sec  = (ts)->tv_sec; \
		(tv)->tv_usec = (ts)->tv_nsec / 1000; \
	    }
#endif // TIMESPEC_TO_TIMEVAL
void calcFPS(bool enable)
{
	static int32_t frame_num = -1;
	static struct timeval start_tv;
	struct timeval  tv, delta_tv;
	struct timespec ts;

	if (enable) {
		clock_gettime(CLOCK_REALTIME, &ts);
		TIMESPEC_TO_TIMEVAL(&tv, &ts);

		frame_num++;

		if (frame_num > 0) {
			timersub(&tv, &start_tv, &delta_tv);
			long delta_us = delta_tv.tv_sec * 1000000 + delta_tv.tv_usec;
			if (delta_us > 1000000) {
				printf("%.2f fps\n", frame_num * 1000000 / (float)delta_us);
				frame_num = 0;
			}
		}
		if (frame_num <= 0) {
			start_tv = tv;
		}
	}
}

