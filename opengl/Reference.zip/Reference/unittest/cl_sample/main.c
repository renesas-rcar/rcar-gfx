#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include <CL/cl.h>

const char* kernelSource =
"__kernel void matrix_mul(__global float* A, __global float* B, __global float* C, const int M, const int N, const int K) {"
"    int tileSize = 16;"
"    int row = get_group_id(0) * tileSize + get_local_id(0);"
"    int col = get_group_id(1) * tileSize + get_local_id(1);"
"    __local float A_tile[tileSize][tileSize];"
"    __local float B_tile[tileSize][tileSize];"
"    float sum = 0.0f;"
"    for (int i = 0; i < K; i += tileSize) {"
"        if (row < M && i + get_local_id(1) < K) {"
"            A_tile[get_local_id(0)][get_local_id(1)] = A[row * K + i + get_local_id(1)];"
"        } else {"
"            A_tile[get_local_id(0)][get_local_id(1)] = 0.0f;"
"        }"
"        if (i + get_local_id(0) < K && col < N) {"
"            B_tile[get_local_id(0)][get_local_id(1)] = B[(i + get_local_id(0)) * N + col];"
"        } else {"
"            B_tile[get_local_id(0)][get_local_id(1)] = 0.0f;"
"        }"
"        barrier(CLK_LOCAL_MEM_FENCE);"
"        for (int j = 0; j < tileSize; j++) {"
"            sum += A_tile[get_local_id(0)][j] * B_tile[j][get_local_id(1)];"
"        }"
"        barrier(CLK_LOCAL_MEM_FENCE);"
"    }"
"    if (row < M && col < N) {"
"        C[row * N + col] = sum;"
"    }"
"}";

void matrixMulCpu(float *A, float *B, float *C, const int M, const int N, const int K)
{
    for (int i = 0; i < M; i++) {
        for (int j = 0; j < N; j++) {
            float sum = 0.0f;
            for (int k = 0; k < K; k++) {
                sum += A[j * K + i] * B[i * N + i];
            }
            C[j * N + i] = sum;
        }
    }
}

int main() {
    // Matrix value
    const int M = 1000;
    const int N = 1000;
    const int K = 1000;

    // Vector size
    float *A = (float*)malloc(M * K * sizeof(float));
    float *B = (float*)malloc(K * N * sizeof(float));
    float *C = (float*)malloc(M * N * sizeof(float));

    memset(A, 1, M * K * sizeof(float));
    memset(B, 2, K * N * sizeof(float));
    memset(C, 0, M * N * sizeof(float));

    // Get platform and device information
    cl_platform_id platformId = NULL;
    cl_device_id deviceId = NULL;
    cl_uint numPlatforms;
    cl_uint numDevices;
	printf("Creating OpenCL device and platform\n");
    cl_int ret = clGetPlatformIDs(1, &platformId, &numPlatforms);
    ret = clGetDeviceIDs(platformId, CL_DEVICE_TYPE_GPU, 1, &deviceId, &numDevices);

    // Create an OpenCL context
    cl_context context = clCreateContext(NULL, 1, &deviceId, NULL, NULL, &ret);

    // Create a command queue
	printf("Creating OpenCL Create a command queue\n");
    cl_command_queue commandQueue = clCreateCommandQueueWithProperties(context, deviceId, 0, &ret);

    // Create memory buffers on the device for each vector
	printf("Creating OpenCL Create memory buffers\n");
    cl_mem aMemObj = clCreateBuffer(context, CL_MEM_READ_ONLY, M * K * sizeof(float), NULL, &ret);
    cl_mem bMemObj = clCreateBuffer(context, CL_MEM_READ_ONLY, K * N * sizeof(float), NULL, &ret);
    cl_mem cMemObj = clCreateBuffer(context, CL_MEM_WRITE_ONLY, M * N * sizeof(float), NULL, &ret);

    // Copy the vectors to their respective memory buffers
	printf("Copying the vectors to their respective memory buffers\n");
    ret = clEnqueueWriteBuffer(commandQueue, aMemObj, CL_TRUE, 0, M * K * sizeof(float), A, 0, NULL, NULL);
    ret = clEnqueueWriteBuffer(commandQueue, bMemObj, CL_TRUE, 0, K * N * sizeof(float), B, 0, NULL, NULL);

    // Create a program from the kernel source
	printf("Creating a program from the kernel source\n");
    cl_program program = clCreateProgramWithSource(context, 1, &kernelSource, NULL, &ret);

    // Build the program
	printf("Building the program\n");
    ret = clBuildProgram(program, 1, &deviceId, NULL, NULL, NULL);

    // Create the OpenCL kernel
	printf("Creating the OpenCL kernel\n");
    cl_kernel kernel = clCreateKernel(program, "matrix_mul", &ret);

    // Set the arguments of the kernel
    ret = clSetKernelArg(kernel, 0, sizeof(cl_mem), &aMemObj);
    ret = clSetKernelArg(kernel, 1, sizeof(cl_mem), &bMemObj);
    ret = clSetKernelArg(kernel, 2, sizeof(cl_mem), &cMemObj);
    ret = clSetKernelArg(kernel, 3, sizeof(int), &M);
    ret = clSetKernelArg(kernel, 4, sizeof(int), &N);
    ret = clSetKernelArg(kernel, 5, sizeof(int), &K);

    // Execute the OpenCL kernel on the list
    size_t globalItemSize[2] = {M, N};
    size_t localItemSize = {16, 16}; // tile size

    // Measure the execution time
	printf("Program running and Measuring the execution time\n");
    clock_t start = clock();
    ret = clEnqueueNDRangeKernel(commandQueue, kernel, 2, NULL, globalItemSize, localItemSize, 0, NULL, NULL);
    ret = clFinish(commandQueue);
    clock_t end = clock();
    double elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;

    // Read the memory buffer C on the device to the local variable C
	// printf("Read the memory buffer C on the device\n");
    // ret = clEnqueueReadBuffer(commandQueue, cMemObj, CL_TRUE, 0, N * sizeof(float), C, 0, NULL, NULL);

    // Display the result
    printf("\t\tExecution time by OpenCL: %f seconds\n", elapsed);
	
	start = clock();
	matrixMulCpu(A, B, C, M, N, K);
	end = clock();
    elapsed = ((double)(end - start)) / CLOCKS_PER_SEC;
	printf("\t\tExecution time by CPU: %f seconds\n", elapsed);

    // Clean up
    ret = clFlush(commandQueue);
    ret = clFinish(commandQueue);
    if (ret == CL_SUCCESS )
    {
        printf("clFinish success \n");
    } else {
        printf("clFinish not success \n");
    }

    ret = clReleaseMemObject(aMemObj);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseMemObject success \n");
    } else {
        printf("clReleaseMemObject not success \n");
    }

    ret = clReleaseMemObject(bMemObj);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseMemObject success \n");
    } else {
        printf("clReleaseMemObject not success \n");
    }

    ret = clReleaseMemObject(cMemObj);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseMemObject success \n");
    } else {
        printf("clReleaseMemObject not success \n");
    }

    ret = clReleaseKernel(kernel);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseKernel success \n");
    } else {
        printf("clReleaseKernel not success \n");
    }

    ret = clReleaseProgram(program);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseProgram success \n");
    } else {
        printf("clReleaseProgram not success \n");
    }

    ret = clReleaseCommandQueue(commandQueue);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseCommandQueue success \n");
    } else {
        printf("clReleaseCommandQueue not success \n");
    }

    ret = clReleaseContext(context);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseContext success \n");
    } else {
        printf("clReleaseContext not success \n");
    }

    ret = clReleaseDevice(deviceId);
    if (ret == CL_SUCCESS )
    {
        printf("clReleaseDevice success \n");
    } else {
        printf("clReleaseDevice not success \n");
    }

	printf("free buffer\n");
    free(A);
    free(B);
    free(C);
    // free(kernelSource);

    return 0;
}