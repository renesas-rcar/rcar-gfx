#ifndef RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_TYPES_H
#define RENESAS_MIDDLEWARE_LIBRARIES_LDR_LIB_INCLUDE_RCAR_XOS_LDR_LIB_R_LDR_TYPES_H

#include <stdint.h>

#ifdef __cplusplus
extern "C" {
#endif


#define LDR_ID_SIZE 4U

typedef enum
{
    LDR_RET_NO_CONTEXT_AVAILABLE = -16,
    LDR_RET_ERROR_NOT_INITIALIZED = -16,
    LDR_RET_HOUSE_KEEPR_ALREADY_RUNNING_ERROR = -15,
    LDR_RET_HOUSE_KEEPER_CREATE_ERROR = -14,
    LDR_RET_MULTIPLE_REGISTER_ERROR = -13,
    LDR_RET_USR_MSG_FORMAT_ERROR = -12,
    LDR_RET_NO_CLIENT_CONNECTED = -11,
    LDR_RET_OVERFLOW = -10,
    LDR_RET_ALREADY_EXSITS = -9,
    LDR_RET_FILESZERR = -8,
    LDR_RET_LOGGING_DISABLED = -7,
    LDR_RET_USER_BUFFER_FULL = -6,
    LDR_RET_WRONG_PARAMETER = -5,
    LDR_RET_BUFFER_FULL = -4,
    LDR_RET_PIPE_FULL = -3,
    LDR_RET_PIPE_ERROR = -2,
    LDR_RET_ERROR = -1,
    LDR_RET_OK = 0,
    LDR_RET_TRUE = 1,
    LDR_RET_ALLOW =2,
} LdrReturnValue;


typedef enum
{
	LDR_AUTO_TIMESTAMP = 0,
	LDR_USER_TIMESTAMP
} LdrTimestampType;

typedef enum
{
    LL_UNSET   = -2,
    LL_DEFAULT = -1,               /* Default log level */
    LL_OFF = 0x00,                 /* Log level off */
    LL_FATAL = 0x01,               /* fatal system error */
    LL_ERROR = 0x02,               /* error with impact to correct functionality */
    LL_WARN = 0x03,                /* warning, correct behaviour could not be ensured */
    LL_INFO = 0x04,                /* informational */
    LL_DEBUG = 0x05,               /* debug  */
    LL_VERBOSE = 0x06,             /* highest grade of information */
    LL_MAX                         /* maximum value, used for range check */
} LdrLogLevelType;


/**
 * Definitions of LDR trace status
 */
typedef enum
{
    LDR_TRACE_STATUS_DEFAULT = -1,         /* Default trace status */
    LDR_TRACE_STATUS_OFF = 0x00,           /* Trace status: Off */
    LDR_TRACE_STATUS_ON = 0x01,            /* Trace status: On */
    LDR_TRACE_STATUS_MAX                   /* maximum value, used for range check */
} LdrTraceStatusType;


// TODO: LdrLogLevelType or LdrLogLevel
typedef LdrLogLevelType LdrLogLevel;

#ifdef __cplusplus
}
#endif

#endif