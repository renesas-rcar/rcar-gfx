/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_command.c
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
/****************************************************************************/
/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdio.h>
#include <stdlib.h>
#include "vulkan/vulkan.h"
#include "vk_sample.h"

/****************************************************************************
 *  GLOBALS
 ****************************************************************************/
uint32_t g_BufferIndex = 0;

/*****************************************************************************
 * Function Name  : BeginCommandBuffer
 * Description    : Begin Command Buffer
 *****************************************************************************/
VkResult BeginCommandBuffer(VkCommandBuffer command, VkFramebuffer fb)
{
	static VkCommandBufferInheritanceInfo inheritanceInfo = {
		.sType                = VK_STRUCTURE_TYPE_COMMAND_BUFFER_INHERITANCE_INFO,
		.pNext                = NULL,
		.renderPass           = VK_NULL_HANDLE,
		.subpass              = 0,
		.framebuffer          = VK_NULL_HANDLE,
		.occlusionQueryEnable = VK_FALSE,
		.queryFlags           = 0,
		.pipelineStatistics   = 0};
	static VkCommandBufferBeginInfo beginInfo = {
		.sType                = VK_STRUCTURE_TYPE_COMMAND_BUFFER_BEGIN_INFO,
		.pNext                = NULL,
		.flags                = 0,
		.pInheritanceInfo     = &inheritanceInfo};
	;
	VkResult ret;

	inheritanceInfo.framebuffer = fb;
	ret = vkBeginCommandBuffer(command, &beginInfo);
	if (ret != VK_SUCCESS) {
		printf("error: vkBeginCommandBuffer failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : EndCommandBuffer
 * Description    : End Command Buffer
 *****************************************************************************/
VkResult EndCommandBuffer(VkCommandBuffer command)
{
	VkResult ret;

	ret = vkEndCommandBuffer(command);
	if (ret != VK_SUCCESS) {
		printf("error: vkEndCommandBuffer failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : QueueSubmit
 * Description    : Queue Submit
 *****************************************************************************/
VkResult QueueSubmit(VkCommandBuffer command, VkFence fence, VkSemaphore wait, VkSemaphore signal)
{
	VkPipelineStageFlags myPipelineStageFlags = VK_PIPELINE_STAGE_BOTTOM_OF_PIPE_BIT;
	VkSubmitInfo submitInfo = {
		.sType                = VK_STRUCTURE_TYPE_SUBMIT_INFO,
		.pNext                = NULL,
		.waitSemaphoreCount   = 0,
		.pWaitSemaphores      = VK_NULL_HANDLE,
		.pWaitDstStageMask    = &myPipelineStageFlags,
		.commandBufferCount   = 1,
		.pCommandBuffers      = &command,
		.signalSemaphoreCount = 0,
		.pSignalSemaphores    = VK_NULL_HANDLE};

	VkResult ret;

	if (wait != VK_NULL_HANDLE) {
		submitInfo.waitSemaphoreCount = sizeof(wait) / sizeof(VkSemaphore);
		submitInfo.pWaitSemaphores = &wait;
	}

	if (signal != VK_NULL_HANDLE) {
		submitInfo.signalSemaphoreCount = sizeof(signal) / sizeof(VkSemaphore);
		submitInfo.pSignalSemaphores = &signal;
	}

	ret = vkQueueSubmit(g_GraphicsQueue, 1, &submitInfo, fence);
	if (ret != VK_SUCCESS) {
		printf("error: vkQueueSubmit failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}

/*****************************************************************************
 * Function Name  : QueueWaitIdle
 * Description    : Queue Wait Idle
 *****************************************************************************/
VkResult QueueWaitIdle(void)
{
	VkResult ret;

	ret = vkQueueWaitIdle(g_GraphicsQueue);
	if (ret != VK_SUCCESS) {
		printf("error: vkQueueWaitIdle failed.\n");
		return ret;
	}

	return VK_SUCCESS;
}
