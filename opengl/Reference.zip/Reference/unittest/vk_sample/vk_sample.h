/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : vk_sample.h
// CREATED  : 2016.5.1
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-Car H3
// HISTORY  : 2016.5.1
//            - Created release code.
//          : 2016.6.14
//            - Add the processing of the semaphore.
//            - Delete the processing of the fence.
//          : 2016.7.14
//            - Add the extension settings.
//            - Modify minImageCount of Swapchain.
//          : 2017.10.16
//            - Modify memoryTypeIndex of MemoryAllocateInfo.
//          : 2017.10.31
//            - Add a check on the supported surface.
/****************************************************************************/
#ifndef _VK_SAMPLE_H_
#define _VK_SAMPLE_H_

/****************************************************************************
 *  INCLUDES
 ****************************************************************************/
#include <stdbool.h>
#include "vulkan/vulkan.h"

/****************************************************************************
 *  DEFINES
 ****************************************************************************/
#define COMMAND_BUFFER_MAX 4

#define IMAGE_FORMAT VK_FORMAT_B8G8R8A8_UNORM
#define DEPTH_FORMAT VK_FORMAT_D24_UNORM_S8_UINT
#define COLOR_SPACE	 VK_COLORSPACE_SRGB_NONLINEAR_KHR

typedef struct vk_buffer {
	VkImage Image;
	VkImageView View;
} vk_buffer;

typedef struct vk_depth_stencil_buffer {
	VkImage Image;
	VkImageView View;
	VkDeviceMemory Memory;
} vk_depth_stencil_buffer;

typedef struct vk_vertex_buffer {
	VkBuffer Buffer;
	VkDeviceMemory Memory;
	VkVertexInputBindingDescription Bindings;
	VkVertexInputAttributeDescription Attributes[3];
} vk_vertex_buffer;

typedef struct vk_uniform_buffer {
	VkBuffer Buffer;
	VkDeviceMemory Memory;
} vk_uniform_buffer;

/****************************************************************************
 *  DECLARATIONS
 ****************************************************************************/
/* vk_device.c */
extern VkInstance g_Instance;
extern VkDevice g_Device;
extern VkPhysicalDevice g_PhysDevice;
extern VkPhysicalDeviceMemoryProperties g_PhysMemoryProps;
extern VkPhysicalDeviceProperties g_PhysDeviceProps;
extern VkQueue g_GraphicsQueue;
extern uint32_t g_GraphicsFamilyIndex;
extern uint32_t g_QueueFamilyCount;
/* vk_object.c */
extern VkFence g_GraphicsFence;
extern VkSemaphore g_GraphicsImageAcquireSemaphore;
extern VkSemaphore g_GraphicsRenderingCompleteSemaphore;
extern VkCommandPool g_CommandPool;
extern VkCommandBuffer g_CommandBuffers[];
/* vk_display.c */
extern uint32_t g_ConnectorIndex;
extern int32_t g_PlaneIndex;
extern VkExtent2D g_PlaneExtent;
extern VkPresentModeKHR g_PresentMode;
extern VkDisplayKHR g_Display;
extern VkSurfaceKHR g_Surface;
extern VkSwapchainKHR g_Swapchain;
/* vk_buffer.c */
extern uint32_t g_SwapchainCount;
extern vk_buffer *g_BackBuffers;
extern vk_depth_stencil_buffer g_Depth;
/* vk_renderpass.c */
extern VkRenderPass g_RenderPass;
extern VkFramebuffer *g_Framebuffers;
/* vk_command.c */
extern uint32_t g_BufferIndex;
/* vk_pipeline.c */
extern vk_vertex_buffer g_VertexBuf;
extern vk_uniform_buffer g_UniformBuf;
extern uint32_t g_UniformBufBufferSize;
extern VkDescriptorPool g_DescPool;
extern VkDescriptorSetLayout g_DescSetLayout;
extern VkDescriptorSet g_DescSet;
extern VkPipelineLayout g_PipelineLayout;
extern VkPipelineCache g_PipelineCache;
extern VkPipeline g_Pipeline;
extern VkViewport g_Viewport;
extern VkRect2D g_Scissor;
/* vk_util.c */
extern PFN_vkAcquireNextImageKHR                        fn_vkAcquireNextImageKHR;
extern PFN_vkCreateDisplayPlaneSurfaceKHR               fn_vkCreateDisplayPlaneSurfaceKHR;
extern PFN_vkCreateSwapchainKHR                         fn_vkCreateSwapchainKHR;
extern PFN_vkDestroySurfaceKHR                          fn_vkDestroySurfaceKHR;
extern PFN_vkDestroySwapchainKHR                        fn_vkDestroySwapchainKHR;
extern PFN_vkGetDisplayModePropertiesKHR                fn_vkGetDisplayModePropertiesKHR;
extern PFN_vkGetDisplayPlaneSupportedDisplaysKHR        fn_vkGetDisplayPlaneSupportedDisplaysKHR;
extern PFN_vkGetPhysicalDeviceDisplayPlanePropertiesKHR fn_vkGetPhysicalDeviceDisplayPlanePropertiesKHR;
extern PFN_vkGetPhysicalDeviceDisplayPropertiesKHR      fn_vkGetPhysicalDeviceDisplayPropertiesKHR;
extern PFN_vkGetPhysicalDeviceSurfaceCapabilitiesKHR    fn_vkGetPhysicalDeviceSurfaceCapabilitiesKHR;
extern PFN_vkGetPhysicalDeviceSurfaceFormatsKHR         fn_vkGetPhysicalDeviceSurfaceFormatsKHR;
extern PFN_vkGetPhysicalDeviceSurfacePresentModesKHR    fn_vkGetPhysicalDeviceSurfacePresentModesKHR;
extern PFN_vkGetSwapchainImagesKHR                      fn_vkGetSwapchainImagesKHR;
extern PFN_vkQueuePresentKHR                            fn_vkQueuePresentKHR;

/* vk_device.c */
VkResult CreateInstance(void);
VkResult EnumeratePhysicalDevices(void);
VkResult GetPhysicalDeviceProperties(void);
VkResult CreateDeviceAndQueue(void);
VkResult DeviceWaitIdle(void);
void DestroyInstance(void);
void DestroyDevice(void);
/* vk_object.c */
VkResult CreateFence(void);
VkResult CreateSemaphore(void);
VkResult CreateCommandPool(void);
VkResult AllocateCommandBuffers(void);
void DestroyFence(void);
void DestroySemaphore(void);
void DestroyCommandPool(void);
void FreeCommandBuffers(void);
/* vk_display.c */
VkResult CreateDisplayPlaneSurface(void);
VkResult CreateSwapchain(void);
void DestroySurface(void);
void DestroySwapchain(void);
/* vk_buffer.c */
VkResult CreateImage(void);
VkResult CreateImageView(void);
VkResult CreateDepthStencilBuffer(void);
VkResult CreateFramebuffer(void);
void DestroyImageAndImageView(void);
void DestroyDepthImageAndImageView(void);
void DestroyFramebuffer(void);
/* vk_renderpass.c */
VkResult CreateRenderPass(void);
void DestroyRenderPass(void);
/* vk_command.c */
VkResult BeginCommandBuffer(VkCommandBuffer command, VkFramebuffer fb);
VkResult EndCommandBuffer(VkCommandBuffer command);
VkResult QueueSubmit(VkCommandBuffer command, VkFence fence, VkSemaphore wait, VkSemaphore signal);
VkResult QueueWaitIdle(void);
/* vk_pipeline.c */
VkResult CreateVertexBufferAndSetup(void);
VkResult CreateUniformBuffer(void);
VkResult CreateDescriptorPool(void);
VkResult CreateDescriptorSetLayout(void);
VkResult UpdateDescriptorSets(void);
VkResult CreatePipelineLayout(void);
VkResult CreatePipelineCache(void);
VkResult CreateGraphicsPipelines(VkShaderModule vs, VkShaderModule fs);
void DestroyGraphicsPipeline(void);
void DestroyPipelineCache(void);
void DestroyPipelineLayout(void);
void FreeDescriptorSets(void);
void DestroyDescriptorSetLayout(void);
void DestroyDescriptorPool(void);
void DestroyUniformBuffer(void);
void DestroyVertexBuffer(void);
/* vk_util.c */
VkBool32 BindExtensionsAPI(void);
void LoadIdentity(float pMatrix[4][4]);
void MultMatrix(float psRes[4][4], float psSrcA[4][4], float psSrcB[4][4]);
void Persp(float pMatrix[4][4], float fovy, float aspect, float zNear, float zFar);
void Translate(float pMatrix[4][4], float fX, float fY, float fZ);
void Rotate(float pMatrix[4][4], float fX, float fY, float fZ, float fAngle);
VkShaderModule LoadShader(const char *fileName);
uint32_t GetMemoryTypeIndex(VkFlags reqMask, uint32_t typeBits);
void calcFPS(bool enable);

#endif /* _VK_SAMPLE_H_ */
