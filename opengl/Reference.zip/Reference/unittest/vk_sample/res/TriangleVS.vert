/****************************************************************************/
// (C) 2016 Renesas Electronics Corporation. All rights reserved.
//
// Vulkan 1.0 sample application
//
// FILE     : TriangleVS.vert
// CREATED  : 2016.4.11
// MODIFIED :
// AUTHOR   : Renesas Electronics Corporation
// DEVICE   : R-car H3
// HISTORY  : 2016.4.11
//            - Created release code.
/****************************************************************************/
#version 450

/* Input Definitions */
layout(location = 0) in vec3 InputPosition;
layout(location = 1) in vec2 InputTexCoord;
layout(location = 2) in vec4 InputColor;

/* Output Definitions */
layout(location = 0) out vec2 OutputTexCoord;
layout(location = 1) out vec4 OutputColor;
out gl_PerVertex
{
	vec4 gl_Position;
};

/* Uniform Buffers */
layout(std140, binding = 0) uniform Transform
{
	mat4x4 mvp;
};

/*****************************************************************************
 * Function Name  : main
 * Description    : 
 *****************************************************************************/
void main()
{
	vec4 localPos = vec4(InputPosition, 1.0f);

	gl_Position = mvp * localPos;
	OutputTexCoord = InputTexCoord;
	OutputColor = InputColor;
}
